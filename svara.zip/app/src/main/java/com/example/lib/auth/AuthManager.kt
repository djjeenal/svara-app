package com.example.lib.auth

import android.util.Log
import com.example.lib.firebase.FirebaseManager
import com.example.lib.firebase.FirebaseManager.isServiceReady
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class UserRole {
    USER,       // Listener (home, search, library, player)
    ARTIST,     // Content Creator (dashboard, upload, releases, analytics, settings)
    ADMIN,      // Manager (approvals, featured highlights, user roles)
    SUPER_ADMIN // System Master
}

data class SvaraUser(
    val uid: String,
    val email: String,
    val displayName: String,
    val role: UserRole,
    val isPremium: Boolean = true
)

/**
 * Production-ready AuthManager integrating with Firebase Auth & Firestore.
 */
class AuthManager {
    private val _currentUser = MutableStateFlow<SvaraUser?>(null)
    val currentUser: StateFlow<SvaraUser?> = _currentUser.asStateFlow()

    init {
        checkCurrentSession()
    }

    fun checkCurrentSession() {
        if (isServiceReady()) {
            val firebaseUser = FirebaseManager.auth.currentUser
            if (firebaseUser != null) {
                // Ensure profile reloading to update isEmailVerified status
                firebaseUser.reload().addOnCompleteListener { reloadTask ->
                    val isVerified = firebaseUser.isEmailVerified
                    if (isVerified) {
                        fetchUserRoleFromFirestore(firebaseUser.uid) { role ->
                            if (role != null) {
                                _currentUser.value = SvaraUser(
                                    uid = firebaseUser.uid,
                                    email = firebaseUser.email ?: "",
                                    displayName = firebaseUser.displayName ?: "Svāra Listener",
                                    role = role,
                                    isPremium = true
                                )
                            } else {
                                // Logged in and verified, but role was not selection-finished yet.
                                _currentUser.value = null
                            }
                        }
                    } else {
                        // Email verification pending
                        _currentUser.value = null
                    }
                }
            } else {
                _currentUser.value = null
            }
        } else {
            _currentUser.value = null
        }
    }

    fun fetchUserRoleFromFirestore(uid: String, onComplete: (UserRole?) -> Unit) {
        if (!isServiceReady()) {
            onComplete(null)
            return
        }
        FirebaseManager.firestore.collection("users").document(uid).get()
            .addOnSuccessListener { document ->
                if (document != null && document.exists()) {
                    val roleStr = document.getString("role") ?: "USER"
                    val role = try {
                        UserRole.valueOf(roleStr)
                    } catch (e: Exception) {
                        UserRole.USER
                    }
                    onComplete(role)
                } else {
                    onComplete(null)
                }
            }
            .addOnFailureListener {
                Log.e("AuthManager", "Failed to get user role", it)
                onComplete(null)
            }
    }

    fun saveUserRoleToFirestore(uid: String, email: String, displayName: String, role: UserRole, onComplete: (Boolean) -> Unit) {
        if (!isServiceReady()) {
            onComplete(false)
            return
        }
        val userMap = hashMapOf(
            "uid" to uid,
            "email" to email,
            "displayName" to displayName,
            "role" to role.name,
            "isPremium" to true
        )
        FirebaseManager.firestore.collection("users").document(uid).set(userMap)
            .addOnSuccessListener {
                onComplete(true)
            }
            .addOnFailureListener {
                Log.e("AuthManager", "Failed to save user role", it)
                onComplete(false)
            }
    }

    fun switchRoleForTesting(role: UserRole) {
        _currentUser.value = _currentUser.value?.copy(role = role)
    }

    fun setLoggedInUser(user: SvaraUser) {
        _currentUser.value = user
    }

    fun signOut() {
        if (isServiceReady()) {
            FirebaseManager.auth.signOut()
        }
        _currentUser.value = null
    }
}
