package com.example.lib.firebase

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

/**
 * Production-ready Firebase manager providing thread-safe operations
 * and lazy-initialized clients for Google Firebase.
 */
object FirebaseManager {
    
    val auth: FirebaseAuth by lazy {
        FirebaseAuth.getInstance()
    }

    val firestore: FirebaseFirestore by lazy {
        FirebaseFirestore.getInstance()
    }

    /**
     * Helper to verify if Firebase initialization credentials/services are available at runtime.
     */
    fun isServiceReady(): Boolean {
        return try {
            auth.app != null
        } catch (e: Exception) {
            false
        }
    }
}
