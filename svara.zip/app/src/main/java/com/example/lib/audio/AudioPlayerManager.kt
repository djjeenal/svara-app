package com.example.lib.audio

import android.media.MediaPlayer
import android.util.Log
import android.content.Context
import android.widget.Toast
import com.example.lib.firebase.FirebaseManager
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val durationSeconds: Int,
    val audioUrl: String,
    val coverArtUrl: String,
    val language: String = "Gujarati",
    val featuringArtists: String = ""
)

enum class RepeatMode {
    NONE,
    ALL,
    ONE
}

/**
 * Native audio stream player engine for premium playback in Gujarati Music Box (Svāra).
 * Integrated with real Android MediaPlayer for cloud URL/Firebase streaming.
 * Features Real-time Firestore Sync for Liked Songs, Listening History, & Live Queues.
 */
object AudioPlayerManager {
    private const val TAG = "AudioPlayerManager"

    private var mediaPlayer: MediaPlayer? = null

    private val _currentTrack = MutableStateFlow<Track?>(null)
    val currentTrack: StateFlow<Track?> = _currentTrack.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _playbackError = MutableStateFlow<String?>(null)
    val playbackError: StateFlow<String?> = _playbackError.asStateFlow()

    private val _playbackProgress = MutableStateFlow(0f) // 0.0 to 1.0
    val playbackProgress: StateFlow<Float> = _playbackProgress.asStateFlow()

    private val _currentSeconds = MutableStateFlow(0)
    val currentSeconds: StateFlow<Int> = _currentSeconds.asStateFlow()

    // Real-time Queue list
    private val _queue = MutableStateFlow<List<Track>>(emptyList())
    val queue: StateFlow<List<Track>> = _queue.asStateFlow()

    private val _isShuffle = MutableStateFlow(false)
    val isShuffle: StateFlow<Boolean> = _isShuffle.asStateFlow()

    private val _repeatMode = MutableStateFlow(RepeatMode.NONE)
    val repeatMode: StateFlow<RepeatMode> = _repeatMode.asStateFlow()

    // real user state
    private var currentUserId: String? = null

    // Real-time Liked Tracks
    private val _likedTrackIds = MutableStateFlow<Set<String>>(emptySet())
    val likedTrackIds: StateFlow<Set<String>> = _likedTrackIds.asStateFlow()

    // Available discovery tracks
    private val _allAvailableTracks = MutableStateFlow<List<Track>>(emptyList())
    val allAvailableTracks: StateFlow<List<Track>> = _allAvailableTracks.asStateFlow()

    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private var progressJob: Job? = null

    private val defaultPlaylist = listOf(
        Track(
            id = "t1",
            title = "Kesariya Sūra",
            artist = "Aman Vyas",
            album = "Mitti Na Sura",
            durationSeconds = 245,
            audioUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
            coverArtUrl = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300",
            featuringArtists = "Prarthana Raval"
        ),
        Track(
            id = "t2",
            title = "Gujarati Garbo - Heritage Gold",
            artist = "Falguni Dave",
            album = "Navratri Vibe 2026",
            durationSeconds = 188,
            audioUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
            coverArtUrl = "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300",
            featuringArtists = "Devang Patel"
        ),
        Track(
            id = "t3",
            title = "Kutch Kutch Kehta Hai",
            artist = "Parthiv Patel",
            album = "Desert Sands",
            durationSeconds = 210,
            audioUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
            coverArtUrl = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300",
            featuringArtists = "Geeta Rabari"
        )
    )

    init {
        _allAvailableTracks.value = defaultPlaylist
        _queue.value = defaultPlaylist
        _currentTrack.value = defaultPlaylist[0]

        // Connect Snapshot Listener to Firestore 'songs' and 'releases' to load uploaded real tracks in real-time
        listenToFirestoreCollections()
    }

    private fun listenToFirestoreCollections() {
        if (!FirebaseManager.isServiceReady()) return

        // 1. Sync 'songs' collection
        FirebaseManager.firestore.collection("songs")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Listen failing for songs collection", error)
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val firestoreTracks = snapshot.documents.mapNotNull { doc ->
                        val id = doc.id
                        val title = doc.getString("title") ?: return@mapNotNull null
                        val artist = doc.getString("artist") ?: "Unknown Artist"
                        val album = doc.getString("album") ?: "Single"
                        val audioUrl = doc.getString("audioUrl") ?: return@mapNotNull null
                        val coverUrl = doc.getString("coverArtUrl") ?: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300"
                        val feat = doc.getString("featuring") ?: ""
                        val durationStr = doc.getString("duration")
                        val durationSec = parseDurationStringToSeconds(durationStr)
                        Track(
                            id = id,
                            title = title,
                            artist = artist,
                            album = album,
                            durationSeconds = durationSec,
                            audioUrl = audioUrl,
                            coverArtUrl = coverUrl,
                            featuringArtists = feat
                        )
                    }
                    mergeTracksWithDefaults(firestoreTracks)
                }
            }

        // 2. Sync 'releases' collection
        FirebaseManager.firestore.collection("releases")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Listen failing for releases collection", error)
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val releaseTracks = snapshot.documents.mapNotNull { doc ->
                        val status = doc.getString("status")
                        if (status != "live") return@mapNotNull null

                        val id = doc.id
                        val title = doc.getString("title") ?: return@mapNotNull null
                        val artist = doc.getString("artist") ?: "Unknown Artist"
                        val album = doc.getString("album") ?: "Single"
                        val audioUrl = doc.getString("audioUrl") ?: return@mapNotNull null
                        val coverUrl = doc.getString("coverArtUrl") ?: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300"
                        val feat = doc.getString("featuring") ?: ""
                        val durationStr = doc.getString("duration")
                        val durationSec = parseDurationStringToSeconds(durationStr)
                        Track(
                            id = id,
                            title = title,
                            artist = artist,
                            album = album,
                            durationSeconds = durationSec,
                            audioUrl = audioUrl,
                            coverArtUrl = coverUrl,
                            featuringArtists = feat
                        )
                    }
                    mergeTracksWithDefaults(releaseTracks)
                }
            }
    }

    private fun mergeTracksWithDefaults(firestoreTracks: List<Track>) {
        val merged = (defaultPlaylist + firestoreTracks).distinctBy { it.id }
        _allAvailableTracks.value = merged
        // Also ensure they are added to queue if queue was default
        if (_queue.value.size <= defaultPlaylist.size) {
            _queue.value = merged
        }
    }

    private fun parseDurationStringToSeconds(durationStr: String?): Int {
        if (durationStr.isNullOrEmpty()) return 180
        return try {
            val parts = durationStr.split(":")
            if (parts.size == 2) {
                val min = parts[0].toIntOrNull() ?: 3
                val sec = parts[1].toIntOrNull() ?: 0
                min * 60 + sec
            } else {
                durationStr.toIntOrNull() ?: 180
            }
        } catch (e: Exception) {
            180
        }
    }

    /**
     * Triggered by MainActivity when current user signs in or changes,
     * to fetch user's customized listening data in real-time.
     */
    fun onUserChanged(uid: String?) {
        currentUserId = uid
        if (uid != null) {
            syncLikesFromFirestore(uid)
            syncQueueFromFirestore(uid)
        } else {
            _likedTrackIds.value = emptySet()
        }
    }

    private fun syncLikesFromFirestore(userId: String) {
        if (!FirebaseManager.isServiceReady()) return
        FirebaseManager.firestore.collection("likedSongs")
            .whereEqualTo("userId", userId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(TAG, "Failed syncing liked songs from Firestore", error)
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val ids = snapshot.documents.mapNotNull { it.getString("trackId") }.toSet()
                    _likedTrackIds.value = ids
                }
            }
    }

    private fun syncQueueFromFirestore(userId: String) {
        if (!FirebaseManager.isServiceReady()) return
        FirebaseManager.firestore.collection("queue").document(userId)
            .get()
            .addOnSuccessListener { document ->
                if (document != null && document.exists()) {
                    val tracksListObj = document.get("tracks") as? List<Map<String, Any>>
                    if (tracksListObj != null && tracksListObj.isNotEmpty()) {
                        val loadedQueue = tracksListObj.mapNotNull { item ->
                            val id = item["id"] as? String ?: return@mapNotNull null
                            val title = item["title"] as? String ?: return@mapNotNull null
                            val artist = item["artist"] as? String ?: "Unknown"
                            val album = item["album"] as? String ?: "Single"
                            val cover = item["coverArtUrl"] as? String ?: ""
                            val audio = item["audioUrl"] as? String ?: ""
                            val duration = (item["durationSeconds"] as? Long)?.toInt() ?: 180
                            val feat = item["featuringArtists"] as? String ?: ""
                            Track(id, title, artist, album, duration, audio, cover, featuringArtists = feat)
                        }
                        if (loadedQueue.isNotEmpty()) {
                            _queue.value = loadedQueue
                        }
                    }
                }
            }
    }

    private fun saveQueueToFirestore() {
        val userId = currentUserId ?: return
        if (!FirebaseManager.isServiceReady()) return
        val mapList = _queue.value.map {
            mapOf(
                "id" to it.id,
                "title" to it.title,
                "artist" to it.artist,
                "album" to it.album,
                "coverArtUrl" to it.coverArtUrl,
                "audioUrl" to it.audioUrl,
                "durationSeconds" to it.durationSeconds,
                "featuringArtists" to it.featuringArtists
            )
        }
        val data = hashMapOf(
            "userId" to userId,
            "tracks" to mapList,
            "timestamp" to FieldValue.serverTimestamp()
        )
        FirebaseManager.firestore.collection("queue").document(userId)
            .set(data, SetOptions.merge())
            .addOnFailureListener {
                Log.e(TAG, "Failed to save queue to Firestore", it)
            }
    }

    fun playTrack(track: Track) {
        // Stop current playing state
        _playbackProgress.value = 0f
        _currentSeconds.value = 0
        _playbackError.value = null
        _isLoading.value = true
        _currentTrack.value = track

        // Make sure the track is in our active queue
        if (!_queue.value.any { it.id == track.id }) {
            _queue.value = _queue.value + track
            saveQueueToFirestore()
        }

        try {
            mediaPlayer?.release()
            mediaPlayer = MediaPlayer().apply {
                setDataSource(track.audioUrl)
                setOnPreparedListener { mp ->
                    _isLoading.value = false
                    _isPlaying.value = true
                    mp.start()
                    // Real audio sync: grab exact streaming duration
                    val realDurationSec = mp.duration / 1000
                    if (realDurationSec > 0 && realDurationSec != track.durationSeconds) {
                        // replace current track with exact duration synced to real audio stream
                        _currentTrack.value = track.copy(durationSeconds = realDurationSec)
                    }
                    startProgressTracking()
                    saveListeningHistory(track)
                }
                setOnCompletionListener {
                    handleTrackFinished()
                }
                setOnErrorListener { _, what, extra ->
                    Log.e(TAG, "MediaPlayer Error: what=$what extra=$extra")
                    _isLoading.value = false
                    _isPlaying.value = false
                    _playbackError.value = "Unable to play track"
                    stopProgressTracking()
                    true
                }
                prepareAsync()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to prepare audio stream", e)
            _isLoading.value = false
            _isPlaying.value = false
            _playbackError.value = "Unable to play track"
        }
    }

    private fun saveListeningHistory(track: Track) {
        val userId = currentUserId ?: return
        if (!FirebaseManager.isServiceReady()) return
        val historyData = hashMapOf(
            "userId" to userId,
            "trackId" to track.id,
            "title" to track.title,
            "artist" to track.artist,
            "album" to track.album,
            "timestamp" to FieldValue.serverTimestamp()
        )
        FirebaseManager.firestore.collection("listeningHistory").add(historyData)
    }

    fun togglePlayback() {
        val mp = mediaPlayer
        if (mp != null) {
            if (mp.isPlaying) {
                mp.pause()
                _isPlaying.value = false
                stopProgressTracking()
            } else {
                _isLoading.value = false
                _isPlaying.value = true
                mp.start()
                startProgressTracking()
            }
        } else {
            // Nothing loaded, play first in queue
            val defaultTrack = _currentTrack.value ?: _queue.value.firstOrNull()
            if (defaultTrack != null) {
                playTrack(defaultTrack)
            }
        }
    }

    fun replay() {
        seekToFraction(0f)
        if (!_isPlaying.value) {
            togglePlayback()
        }
    }

    fun nextTrack() {
        val current = _currentTrack.value ?: return
        val activeQueue = _queue.value
        if (activeQueue.isEmpty()) return

        if (_repeatMode.value == RepeatMode.ONE) {
            // Replay same track
            playTrack(current)
            return
        }

        val nextIndex = if (_isShuffle.value) {
            activeQueue.indices.random()
        } else {
            val currentIndex = activeQueue.indexOfFirst { it.id == current.id }
            if (currentIndex != -1 && currentIndex < activeQueue.size - 1) {
                currentIndex + 1
            } else {
                if (_repeatMode.value == RepeatMode.ALL) 0 else -1
            }
        }

        if (nextIndex != -1) {
            playTrack(activeQueue[nextIndex])
        } else {
            // Stop playback at end of queue
            mediaPlayer?.stop()
            _isPlaying.value = false
            _playbackProgress.value = 0f
            _currentSeconds.value = 0
            stopProgressTracking()
        }
    }

    fun previousTrack() {
        val current = _currentTrack.value ?: return
        val activeQueue = _queue.value
        if (activeQueue.isEmpty()) return

        val prevIndex = if (_isShuffle.value) {
            activeQueue.indices.random()
        } else {
            val currentIndex = activeQueue.indexOfFirst { it.id == current.id }
            if (currentIndex > 0) {
                currentIndex - 1
            } else {
                if (_repeatMode.value == RepeatMode.ALL) activeQueue.size - 1 else -1
            }
        }

        if (prevIndex != -1) {
            playTrack(activeQueue[prevIndex])
        } else {
            // Just replay current song from beginning
            replay()
        }
    }

    fun seekToFraction(fraction: Float) {
        val mp = mediaPlayer ?: return
        val track = _currentTrack.value ?: return
        try {
            val durationMs = mp.duration
            if (durationMs > 0) {
                val targetMs = (durationMs * fraction).toInt()
                mp.seekTo(targetMs)
                _playbackProgress.value = fraction
                _currentSeconds.value = (targetMs / 1000)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Seek error", e)
        }
    }

    fun setShuffle(enabled: Boolean) {
        _isShuffle.value = enabled
    }

    fun cycleRepeatMode() {
        _repeatMode.value = when (_repeatMode.value) {
            RepeatMode.NONE -> RepeatMode.ALL
            RepeatMode.ALL -> RepeatMode.ONE
            RepeatMode.ONE -> RepeatMode.NONE
        }
    }

    fun toggleLikeTrack(track: Track, context: Context? = null) {
        val userId = currentUserId
        if (userId == null) {
            context?.let { Toast.makeText(it, "Sign in to add favorites", Toast.LENGTH_SHORT).show() }
            return
        }
        if (!FirebaseManager.isServiceReady()) {
            // local state fallback
            val currentLikes = _likedTrackIds.value.toMutableSet()
            if (currentLikes.contains(track.id)) {
                currentLikes.remove(track.id)
            } else {
                currentLikes.add(track.id)
            }
            _likedTrackIds.value = currentLikes
            return
        }

        val likedDocId = "${userId}_${track.id}"
        val isCurrentlyLiked = _likedTrackIds.value.contains(track.id)

        if (isCurrentlyLiked) {
            // Dislike
            FirebaseManager.firestore.collection("likedSongs").document(likedDocId).delete()
                .addOnSuccessListener {
                    context?.let { Toast.makeText(it, "Removed from Favorites ♥", Toast.LENGTH_SHORT).show() }
                }
        } else {
            // Like
            val data = hashMapOf(
                "userId" to userId,
                "trackId" to track.id,
                "title" to track.title,
                "artist" to track.artist,
                "coverArtUrl" to track.coverArtUrl,
                "audioUrl" to track.audioUrl,
                "timestamp" to FieldValue.serverTimestamp()
            )
            FirebaseManager.firestore.collection("likedSongs").document(likedDocId).set(data)
                .addOnSuccessListener {
                    context?.let { Toast.makeText(it, "Added to Favorites ♥", Toast.LENGTH_SHORT).show() }
                }
        }
    }

    fun addToQueue(track: Track) {
        if (!_queue.value.any { it.id == track.id }) {
            _queue.value = _queue.value + track
            saveQueueToFirestore()
        }
    }

    fun removeFromQueue(trackId: String) {
        _queue.value = _queue.value.filter { it.id != trackId }
        saveQueueToFirestore()
        // If current track was removed, skip or stop
        if (_currentTrack.value?.id == trackId) {
            nextTrack()
        }
    }

    fun reorderQueue(fromIndex: Int, toIndex: Int) {
        val currentQueue = _queue.value.toMutableList()
        if (fromIndex in currentQueue.indices && toIndex in currentQueue.indices) {
            val moved = currentQueue.removeAt(fromIndex)
            currentQueue.add(toIndex, moved)
            _queue.value = currentQueue
            saveQueueToFirestore()
        }
    }

    private fun handleTrackFinished() {
        nextTrack()
    }

    private fun startProgressTracking() {
        progressJob?.cancel()
        progressJob = scope.launch {
            while (isActive) {
                delay(250) // High precision updates for seek bar
                val mp = mediaPlayer
                val track = _currentTrack.value
                if (mp != null && mp.isPlaying && track != null) {
                    val pos = mp.currentPosition
                    val duration = mp.duration
                    if (duration > 0) {
                        _currentSeconds.value = pos / 1000
                        _playbackProgress.value = pos.toFloat() / duration
                    }
                }
            }
        }
    }

    private fun stopProgressTracking() {
        progressJob?.cancel()
        progressJob = null
    }

    fun getTracksForDiscovery(): List<Track> {
        return _allAvailableTracks.value.ifEmpty { defaultPlaylist }
    }
}
