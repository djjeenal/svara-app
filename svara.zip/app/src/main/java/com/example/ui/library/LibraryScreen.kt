package com.example.ui.library

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FolderSpecial
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.SvaraOutlineButton
import com.example.ui.theme.BorderGoldGray
import com.example.ui.theme.CardSurfaceDark
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.RoyalGold

@Composable
fun LibraryScreen() {
    var isCreatingPlaylist by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(horizontal = 24.dp)
            .padding(bottom = 80.dp)
            .testTag("library_screen_container")
    ) {
        Spacer(modifier = Modifier.height(20.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "YOUR LIBRARY",
                color = RoyalGold,
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.5.sp
            )

            IconButton(
                onClick = { isCreatingPlaylist = true },
                modifier = Modifier.testTag("btn_create_playlist")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Create New Collection", tint = RoyalGold)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Folders Section list
        LibraryItemRow(
            title = "LIKED COMPOSITIONS",
            count = "34 tracks",
            icon = Icons.Default.Favorite,
            tint = RoyalGold
        )

        Spacer(modifier = Modifier.height(14.dp))

        LibraryItemRow(
            title = "OFFLINE VAULT",
            count = "12 downloaded",
            icon = Icons.Default.DownloadDone,
            tint = ChampagneGold
        )

        Spacer(modifier = Modifier.height(14.dp))

        LibraryItemRow(
            title = "CURATED BY EXPERTS",
            count = "5 reference folders",
            icon = Icons.Default.FolderSpecial,
            tint = ChampagneGold
        )

        Spacer(modifier = Modifier.height(28.dp))

        Text(
            text = "CUSTOM COLLECTIONS",
            color = ColorUtils.slateGray(),
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Custom Playlists container
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, BorderGoldGray)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "No custom playlists defined yet",
                    color = ColorUtils.mediumGray(),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(12.dp))
                SvaraOutlineButton(
                    text = "CREATE GOLDEN PLAYLIST",
                    onClick = { isCreatingPlaylist = true },
                    modifier = Modifier.wrapContentWidth()
                )
            }
        }
    }
}

@Composable
fun LibraryItemRow(
    title: String,
    count: String,
    icon: ImageVector,
    tint: androidx.compose.ui.graphics.Color
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, BorderGoldGray)
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(ObsidianBlack, RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = title, tint = tint)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(
                    text = title,
                    color = androidx.compose.ui.graphics.Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = count,
                    color = ChampagneGold,
                    fontSize = 12.sp
                )
            }
        }
    }
}

object ColorUtils {
    fun slateGray(): androidx.compose.ui.graphics.Color = androidx.compose.ui.graphics.Color(0xFF9EA3A5)
    fun mediumGray(): androidx.compose.ui.graphics.Color = androidx.compose.ui.graphics.Color(0xFF757575)
}
