package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Luxury Black & Gold Theme Palette (Svāra) - Sophisticated Dark
val PureBlack = Color(0xFF000000)
val ObsidianBlack = Color(0xFF0A0A0A)
val CharcoalDark = Color(0xFF151515)
val CardSurfaceDark = Color(0xFF1A1A1A)
val BorderGoldGray = Color(0x1AFFFFFF)   // Elegant thin white/10 border

// Sophisticated Gold Spectrum
val RichGold = Color(0xFFC5A028)         // Signature Sophisticated Gold
val RoyalGold = Color(0xFFC5A028)        // Match Signature
val ChampagneGold = Color(0xFFE5C453)    // Lighter elegant gold shade
val DarkBronze = Color(0xFF8A6C16)       // Deep bronze accent
val MutedGold = Color(0xFF9C801F)        // Subtle, elegance-defining gold

// Functional Colors
val SlateGray = Color(0xFF9EA3A6)
val ErrorRed = Color(0xFFE53935)
val SuccessGreen = Color(0xFF4CAF50)
val InputBackground = Color(0xFF151412)
