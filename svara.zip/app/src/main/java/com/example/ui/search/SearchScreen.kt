package com.example.ui.search

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.lib.audio.AudioPlayerManager
import com.example.lib.audio.Track
import com.example.ui.components.SvaraTextField
import com.example.ui.theme.BorderGoldGray
import com.example.ui.theme.CardSurfaceDark
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.RoyalGold

@Composable
fun SearchScreen(
    onTrackSelect: (Track) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val allTracks by AudioPlayerManager.allAvailableTracks.collectAsState()

    val filteredTracks = remember(query, allTracks) {
        if (query.isBlank()) {
            allTracks
        } else {
            allTracks.filter {
                it.title.contains(query, ignoreCase = true) ||
                        it.artist.contains(query, ignoreCase = true) ||
                        it.album.contains(query, ignoreCase = true)
            }
        }
    }

    val genres = listOf("Heritage Folk", "Garba Rocks", "Sugam Sangeet", "Dhol Thumpers", "Gazals")
    var selectedGenre by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(horizontal = 24.dp)
            .padding(bottom = 80.dp)
            .testTag("search_screen_container")
    ) {
        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "SEARCH",
            color = RoyalGold,
            fontSize = 24.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.5.sp
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Search Input Field
        SvaraTextField(
            value = query,
            onValueChange = { query = it },
            label = "Search Tracks, Artists, or Albums",
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = ChampagneGold) },
            placeholder = "Start writing...",
            tag = "svara_search_input"
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Quick Category Badges
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth().testTag("genre_row_list")
        ) {
            items(genres) { genre ->
                val isSelected = selectedGenre == genre
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isSelected) RoyalGold else CardSurfaceDark)
                        .border(1.dp, if (isSelected) RoyalGold else BorderGoldGray, RoundedCornerShape(20.dp))
                        .clickable {
                            selectedGenre = if (isSelected) null else genre
                            // Real app query filter updates
                            if (selectedGenre != null) {
                                query = selectedGenre ?: ""
                            } else {
                                query = ""
                            }
                        }
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = genre,
                        color = if (isSelected) ObsidianBlack else Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = if (query.isBlank()) "POPULAR MATCHES" else "MATCHES FOR \"${query.uppercase()}\"",
            color = Color.Gray,
            fontSize = 12.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Search Matches List
        if (filteredTracks.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No recorded compositions match your filter query.",
                    color = Color.LightGray.copy(alpha = 0.5f),
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredTracks) { track ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onTrackSelect(track) }
                            .background(CardSurfaceDark, RoundedCornerShape(8.dp))
                            .border(1.dp, BorderGoldGray, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                            .testTag("search_result_${track.id}"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(
                            model = track.coverArtUrl,
                            contentDescription = "Cover",
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(6.dp))
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = track.title,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                maxLines = 1
                            )
                            Text(
                                text = track.artist,
                                color = ChampagneGold,
                                fontSize = 12.sp,
                                maxLines = 1
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.MusicNote,
                            contentDescription = "Music",
                            tint = Color.Gray,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}
