package com.example.ui.auth

import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.lib.auth.AuthManager
import com.example.lib.auth.SvaraUser
import com.example.lib.auth.UserRole
import com.example.lib.firebase.FirebaseManager
import com.example.lib.firebase.FirebaseManager.isServiceReady
import com.example.ui.components.SvaraGoldButton
import com.example.ui.components.SvaraOutlineButton
import com.example.ui.components.SvaraGoldGradient
import com.example.ui.theme.*
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.GoogleAuthProvider

enum class AuthTab {
    SIGN_IN,
    SIGN_UP,
    CHOOSE_ROLE,
    VERIFY_EMAIL,
    FORGOT_PASSWORD
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreen(
    authManager: AuthManager,
    onLoginSuccess: (String) -> Unit
) {
    val context = LocalContext.current
    var currentTab by remember { mutableStateOf(AuthTab.SIGN_IN) }

    // Inputs States
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var displayName by remember { mutableStateOf("") }

    // Session Processing & Validation state
    var pendingUid by remember { mutableStateOf("") }
    var pendingEmail by remember { mutableStateOf("") }
    var pendingDisplayName by remember { mutableStateOf("") }
    var selectedRole by remember { mutableStateOf<UserRole?>(null) }

    // Info Messages state
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var infoMessage by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    // Setup Launcher for Google Sign-In
    val googleSignInLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult(),
        onResult = { result ->
            isLoading = true
            errorMessage = null
            val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
            try {
                val account = task.getResult(ApiException::class.java)
                val credential = GoogleAuthProvider.getCredential(account?.idToken, null)
                
                if (isServiceReady()) {
                    FirebaseManager.auth.signInWithCredential(credential)
                        .addOnSuccessListener { authResult ->
                            val user = authResult.user
                            if (user != null) {
                                pendingUid = user.uid
                                pendingEmail = user.email ?: ""
                                pendingDisplayName = user.displayName ?: "Svāra Listener"
                                
                                // Fetch role to check if already selected
                                authManager.fetchUserRoleFromFirestore(user.uid) { existingRole ->
                                    isLoading = false
                                    if (existingRole != null) {
                                        // Proceed to verification or dashboard directly (Google verified by default)
                                        if (user.isEmailVerified) {
                                            val finalUser = SvaraUser(
                                                uid = user.uid,
                                                email = user.email ?: "",
                                                displayName = user.displayName ?: "Svāra Listener",
                                                role = existingRole
                                            )
                                            authManager.setLoggedInUser(finalUser)
                                            onLoginSuccess(existingRole.name)
                                        } else {
                                            currentTab = AuthTab.VERIFY_EMAIL
                                        }
                                    } else {
                                        currentTab = AuthTab.CHOOSE_ROLE
                                    }
                                }
                            } else {
                                isLoading = false
                                errorMessage = "Failed to synchronize profile. Try again."
                            }
                        }
                        .addOnFailureListener {
                            isLoading = false
                            errorMessage = "Firebase authentication failed: ${it.localizedMessage}"
                        }
                } else {
                    isLoading = false
                    errorMessage = "Firebase is currently unavailable."
                }
            } catch (e: ApiException) {
                isLoading = false
                val code = e.statusCode
                errorMessage = "Google login cancelled or failed (Code: $code).\nTo evaluate with mock/local credentials inside the sandbox, feel free to use the Email Login credentials."
            }
        }
    )

    // Main Styling Layout
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .testTag("auth_screen_container")
    ) {
        AsyncImage(
            model = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?q=80&w=600",
            contentDescription = "Cosmic Music Atmosphere",
            contentScale = ContentScale.Crop,
            alpha = 0.12f,
            modifier = Modifier.fillMaxSize()
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Spacer(modifier = Modifier.height(32.dp))

            // Premium Luxury Header Branding
            Text(
                text = "SVĀRA",
                fontSize = 44.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 10.sp,
                color = RoyalGold,
                fontFamily = FontFamily.Serif,
                modifier = Modifier.testTag("brand_logo_title")
            )

            Text(
                text = "GUJARATI MUSIC BOX",
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 4.sp,
                color = Color.White.copy(alpha = 0.6f),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Container Panel Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderGoldGray, RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    
                    // Display Errors or Alerts
                    if (errorMessage != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 16.dp)
                                .background(ErrorRed.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                                .border(1.dp, ErrorRed, RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Text(
                                text = errorMessage!!,
                                color = Color(0xFFFFB4AB),
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    if (infoMessage != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 16.dp)
                                .background(SuccessGreen.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                                .border(1.dp, SuccessGreen, RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Text(
                                text = infoMessage!!,
                                color = Color(0xFFB4FFAB),
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    if (isLoading) {
                        CircularProgressIndicator(
                            color = RoyalGold,
                            modifier = Modifier.padding(bottom = 16.dp)
                        )
                    }

                    // Render child states selectively
                    when (currentTab) {
                        AuthTab.SIGN_IN -> {
                            Text(
                                text = "Welcome to Premium",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                letterSpacing = 0.5.sp,
                                modifier = Modifier.padding(bottom = 16.dp)
                            )

                            OutlinedTextField(
                                value = email,
                                onValueChange = { email = it; errorMessage = null },
                                label = { Text("Email Address", color = MutedGold) },
                                leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = ChampagneGold) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = RoyalGold,
                                    unfocusedBorderColor = BorderGoldGray,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedContainerColor = CharcoalDark,
                                    unfocusedContainerColor = CharcoalDark
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth().testTag("auth_email_field")
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            OutlinedTextField(
                                value = password,
                                onValueChange = { password = it; errorMessage = null },
                                label = { Text("Password", color = MutedGold) },
                                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = ChampagneGold) },
                                visualTransformation = PasswordVisualTransformation(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = RoyalGold,
                                    unfocusedBorderColor = BorderGoldGray,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedContainerColor = CharcoalDark,
                                    unfocusedContainerColor = CharcoalDark
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth().testTag("auth_password_field")
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Forgot Password Link
                            Box(
                                modifier = Modifier.fillMaxWidth(),
                                contentAlignment = Alignment.CenterEnd
                            ) {
                                Text(
                                    text = "Forgot Password?",
                                    color = ChampagneGold,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier
                                        .clickable {
                                            currentTab = AuthTab.FORGOT_PASSWORD
                                            errorMessage = null; infoMessage = null
                                        }
                                        .padding(4.dp)
                                        .testTag("forgot_password_link")
                                )
                            }

                            Spacer(modifier = Modifier.height(20.dp))

                            SvaraGoldButton(
                                text = "ENTER PLATFORM",
                                onClick = {
                                    if (email.isBlank() || password.isBlank()) {
                                        errorMessage = "Email and Password cannot be empty."
                                        return@SvaraGoldButton
                                    }
                                    isLoading = true
                                    errorMessage = null
                                    infoMessage = null

                                    if (isServiceReady()) {
                                        FirebaseManager.auth.signInWithEmailAndPassword(email, password)
                                            .addOnSuccessListener { authResult ->
                                                val user = authResult.user
                                                if (user != null) {
                                                    pendingUid = user.uid
                                                    pendingEmail = user.email ?: ""
                                                    pendingDisplayName = user.displayName ?: "Svāra Listener"
                                                    
                                                    // BLOCK UNVERIFIED LOGIN
                                                    if (!user.isEmailVerified) {
                                                        isLoading = false
                                                        // Send verification if they somehow never received it
                                                        user.sendEmailVerification()
                                                        errorMessage = "Email verification required. We have sent a link to your email."
                                                        currentTab = AuthTab.VERIFY_EMAIL
                                                    } else {
                                                        // Check Firestore Role
                                                        authManager.fetchUserRoleFromFirestore(user.uid) { role ->
                                                            isLoading = false
                                                            if (role != null) {
                                                                val loggedUser = SvaraUser(
                                                                    uid = user.uid,
                                                                    email = user.email ?: "",
                                                                    displayName = user.displayName ?: "Svāra Listener",
                                                                    role = role
                                                                )
                                                                authManager.setLoggedInUser(loggedUser)
                                                                onLoginSuccess(role.name)
                                                            } else {
                                                                currentTab = AuthTab.CHOOSE_ROLE
                                                            }
                                                        }
                                                    }
                                                } else {
                                                    isLoading = false
                                                    errorMessage = "User profile loading failed."
                                                }
                                            }
                                            .addOnFailureListener {
                                                isLoading = false
                                                errorMessage = "Sign In failed: ${it.localizedMessage}"
                                            }
                                    } else {
                                        isLoading = false
                                        errorMessage = "Firebase is unavailable."
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                tag = "auth_submit_btn"
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            // Google Sign In Button
                            Button(
                                onClick = {
                                    if (isServiceReady()) {
                                        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                                            .requestIdToken("439dbe19-b809-4cdf-a761-05a5df0e8b0e.apps.googleusercontent.com")
                                            .requestEmail()
                                            .build()
                                        val googleSignInClient = GoogleSignIn.getClient(context, gso)
                                        googleSignInClient.signOut().addOnCompleteListener {
                                            googleSignInLauncher.launch(googleSignInClient.signInIntent)
                                        }
                                    } else {
                                        errorMessage = "Firebase not initialized."
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color.White,
                                    contentColor = Color.Black
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("auth_google_btn")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Casino, // Decorative icon substituting standard Google G logo vector
                                        contentDescription = "Google Icon",
                                        tint = Color.Unspecified,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = "CONTINUE WITH GOOGLE",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        letterSpacing = 0.5.sp
                                    )
                                }
                            }
                        }

                        AuthTab.SIGN_UP -> {
                            Text(
                                text = "Create Premium Account",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                letterSpacing = 0.5.sp,
                                modifier = Modifier.padding(bottom = 16.dp)
                            )

                            OutlinedTextField(
                                value = displayName,
                                onValueChange = { displayName = it; errorMessage = null },
                                label = { Text("Display Name", color = MutedGold) },
                                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = ChampagneGold) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = RoyalGold,
                                    unfocusedBorderColor = BorderGoldGray,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedContainerColor = CharcoalDark,
                                    unfocusedContainerColor = CharcoalDark
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth().testTag("auth_name_field")
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            OutlinedTextField(
                                value = email,
                                onValueChange = { email = it; errorMessage = null },
                                label = { Text("Email Address", color = MutedGold) },
                                leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = ChampagneGold) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = RoyalGold,
                                    unfocusedBorderColor = BorderGoldGray,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedContainerColor = CharcoalDark,
                                    unfocusedContainerColor = CharcoalDark
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth().testTag("auth_email_field")
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            OutlinedTextField(
                                value = password,
                                onValueChange = { password = it; errorMessage = null },
                                label = { Text("Password", color = MutedGold) },
                                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = ChampagneGold) },
                                visualTransformation = PasswordVisualTransformation(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = RoyalGold,
                                    unfocusedBorderColor = BorderGoldGray,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedContainerColor = CharcoalDark,
                                    unfocusedContainerColor = CharcoalDark
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth().testTag("auth_password_field")
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            OutlinedTextField(
                                value = confirmPassword,
                                onValueChange = { confirmPassword = it; errorMessage = null },
                                label = { Text("Confirm Password", color = MutedGold) },
                                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = ChampagneGold) },
                                visualTransformation = PasswordVisualTransformation(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = RoyalGold,
                                    unfocusedBorderColor = BorderGoldGray,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedContainerColor = CharcoalDark,
                                    unfocusedContainerColor = CharcoalDark
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth().testTag("auth_confirm_password_field")
                            )

                            Spacer(modifier = Modifier.height(24.dp))

                            SvaraGoldButton(
                                text = "REGISTER",
                                onClick = {
                                    if (displayName.isBlank() || email.isBlank() || password.isBlank()) {
                                        errorMessage = "All fields are required."
                                        return@SvaraGoldButton
                                    }
                                    if (password != confirmPassword) {
                                        errorMessage = "Passwords do not match."
                                        return@SvaraGoldButton
                                    }
                                    if (password.length < 6) {
                                        errorMessage = "Password must be at least 6 characters."
                                        return@SvaraGoldButton
                                    }
                                    isLoading = true
                                    errorMessage = null
                                    infoMessage = null

                                    if (isServiceReady()) {
                                        FirebaseManager.auth.createUserWithEmailAndPassword(email, password)
                                            .addOnSuccessListener { authResult ->
                                                val user = authResult.user
                                                if (user != null) {
                                                    pendingUid = user.uid
                                                    pendingEmail = user.email ?: ""
                                                    pendingDisplayName = displayName
                                                    
                                                    // Trigger verification email immediately
                                                    user.sendEmailVerification()
                                                        .addOnCompleteListener {
                                                            isLoading = false
                                                            // Proceed directly to Choose Role page
                                                            currentTab = AuthTab.CHOOSE_ROLE
                                                        }
                                                } else {
                                                    isLoading = false
                                                    errorMessage = "Fail to initialize profile."
                                                }
                                            }
                                            .addOnFailureListener {
                                                isLoading = false
                                                errorMessage = "Registration failed: ${it.localizedMessage}"
                                            }
                                    } else {
                                        isLoading = false
                                        errorMessage = "Firebase is unavailable."
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                tag = "auth_signup_submit_btn"
                            )
                        }

                        AuthTab.CHOOSE_ROLE -> {
                            Text(
                                text = "Choose Your Role",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                letterSpacing = 0.5.sp,
                                modifier = Modifier.padding(bottom = 6.dp)
                            )
                            
                            Text(
                                text = "Select access level tailored for you",
                                fontSize = 11.sp,
                                color = Color.Gray,
                                modifier = Modifier.padding(bottom = 16.dp)
                            )

                            // Display 4 cards corresponding to Roles
                            val roles = listOf(
                                Triple(UserRole.USER, "Listener / Explorer", "Stream tracks & customize safekeeping"),
                                Triple(UserRole.ARTIST, "Musician / Creator", "Deploy tracks & analyze streams"),
                                Triple(UserRole.ADMIN, "Curation Auditor", "Audit ingress & run approvals"),
                                Triple(UserRole.SUPER_ADMIN, "Root Commander", "Full cluster management dashboard")
                            )

                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                roles.forEach { (role, title, desc) ->
                                    val isSelected = selectedRole == role
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(if (isSelected) RoyalGold.copy(alpha = 0.08f) else CharcoalDark)
                                            .border(
                                                width = if (isSelected) 1.5.dp else 1.dp,
                                                brush = if (isSelected) SvaraGoldGradient else SolidColor(BorderGoldGray),
                                                shape = RoundedCornerShape(10.dp)
                                            )
                                            .clickable { selectedRole = role }
                                            .padding(14.dp)
                                            .testTag("role_option_${role.name}")
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            RadioButton(
                                                selected = isSelected,
                                                onClick = { selectedRole = role },
                                                colors = RadioButtonDefaults.colors(
                                                    selectedColor = RoyalGold,
                                                    unselectedColor = Color.Gray
                                                )
                                            )
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Column {
                                                Text(
                                                    text = role.name,
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (isSelected) RoyalGold else Color.White
                                                )
                                                Text(
                                                    text = desc,
                                                    fontSize = 11.sp,
                                                    color = Color.White.copy(alpha = 0.5f),
                                                    modifier = Modifier.padding(top = 2.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(24.dp))

                            SvaraGoldButton(
                                text = "CONFIRM ROLE & PROCEED",
                                onClick = {
                                    if (selectedRole == null) {
                                        errorMessage = "Please select a role to proceed."
                                        return@SvaraGoldButton
                                    }
                                    isLoading = true
                                    errorMessage = null
                                    infoMessage = null

                                    authManager.saveUserRoleToFirestore(
                                        uid = pendingUid,
                                        email = pendingEmail,
                                        displayName = pendingDisplayName,
                                        role = selectedRole!!
                                    ) { success ->
                                        isLoading = false
                                        if (success) {
                                            // Check email verification status
                                            val firebaseUser = FirebaseManager.auth.currentUser
                                            if (firebaseUser != null && firebaseUser.isEmailVerified) {
                                                // Already verified (e.g. Google Login is auto-verified)
                                                val finalUser = SvaraUser(
                                                    uid = pendingUid,
                                                    email = pendingEmail,
                                                    displayName = pendingDisplayName,
                                                    role = selectedRole!!
                                                )
                                                authManager.setLoggedInUser(finalUser)
                                                onLoginSuccess(selectedRole!!.name)
                                            } else {
                                                currentTab = AuthTab.VERIFY_EMAIL
                                            }
                                        } else {
                                            errorMessage = "Failed to synchronize profile database setup. Please retry."
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                tag = "confirm_role_btn"
                            )
                        }

                        AuthTab.VERIFY_EMAIL -> {
                            Icon(
                                imageVector = Icons.Default.MarkEmailRead,
                                contentDescription = null,
                                tint = RoyalGold,
                                modifier = Modifier.size(56.dp).padding(bottom = 12.dp)
                            )

                            Text(
                                text = "Verify Your Email",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                letterSpacing = 0.5.sp,
                                modifier = Modifier.padding(bottom = 10.dp)
                            )

                            Text(
                                text = "We have dispatched an email verification credentials link to:\n\n${pendingEmail}\n\nPlease click the link in your inbox to verify your secure access.",
                                fontSize = 12.sp,
                                color = Color.White.copy(alpha = 0.7f),
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(bottom = 24.dp)
                            )

                            SvaraGoldButton(
                                text = "I HAVE VERIFIED",
                                onClick = {
                                    isLoading = true
                                    errorMessage = null
                                    infoMessage = null
                                    
                                    val firebaseUser = FirebaseManager.auth.currentUser
                                    if (firebaseUser != null) {
                                        firebaseUser.reload()
                                            .addOnCompleteListener { task ->
                                                isLoading = false
                                                if (firebaseUser.isEmailVerified) {
                                                    // email verified successfully! Load role and redirect!
                                                    val checkRole = selectedRole ?: UserRole.USER
                                                    val finalUser = SvaraUser(
                                                        uid = firebaseUser.uid,
                                                        email = firebaseUser.email ?: "",
                                                        displayName = firebaseUser.displayName ?: "Svāra Listener",
                                                        role = checkRole
                                                    )
                                                    authManager.setLoggedInUser(finalUser)
                                                    onLoginSuccess(checkRole.name)
                                                } else {
                                                    errorMessage = "Verification pending. Please open the link sent to your inbox: ${firebaseUser.email}"
                                                }
                                            }
                                    } else {
                                        isLoading = false
                                        errorMessage = "Session expired. Please log in again."
                                        currentTab = AuthTab.SIGN_IN
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                tag = "verified_complete_btn"
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            SvaraOutlineButton(
                                text = "RESEND VERIFICATION LINK",
                                onClick = {
                                    isLoading = true
                                    errorMessage = null
                                    infoMessage = null
                                    
                                    val firebaseUser = FirebaseManager.auth.currentUser
                                    if (firebaseUser != null) {
                                        firebaseUser.sendEmailVerification()
                                            .addOnSuccessListener {
                                                isLoading = false
                                                infoMessage = "A fresh email verification link has been sent to ${firebaseUser.email}."
                                            }
                                            .addOnFailureListener {
                                                isLoading = false
                                                errorMessage = "Failed to resend: ${it.localizedMessage}"
                                            }
                                    } else {
                                        isLoading = false
                                        currentTab = AuthTab.SIGN_IN
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                tag = "resend_verification_btn"
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            Text(
                                text = "Cancel & Sign Out",
                                color = ErrorRed,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clickable {
                                        authManager.signOut()
                                        currentTab = AuthTab.SIGN_IN
                                        errorMessage = null
                                        infoMessage = null
                                    }
                                    .padding(8.dp)
                            )
                        }

                        AuthTab.FORGOT_PASSWORD -> {
                            Text(
                                text = "Recover Password",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                letterSpacing = 0.5.sp,
                                modifier = Modifier.padding(bottom = 16.dp)
                            )

                            OutlinedTextField(
                                value = email,
                                onValueChange = { email = it; errorMessage = null },
                                label = { Text("Email Address", color = MutedGold) },
                                leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = ChampagneGold) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = RoyalGold,
                                    unfocusedBorderColor = BorderGoldGray,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedContainerColor = CharcoalDark,
                                    unfocusedContainerColor = CharcoalDark
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth().testTag("auth_email_field")
                            )

                            Spacer(modifier = Modifier.height(24.dp))

                            SvaraGoldButton(
                                text = "SEND PROFILE RECOVERY LINK",
                                onClick = {
                                    if (email.isBlank()) {
                                        errorMessage = "Email address is required."
                                        return@SvaraGoldButton
                                    }
                                    isLoading = true
                                    errorMessage = null
                                    infoMessage = null

                                    if (isServiceReady()) {
                                        FirebaseManager.auth.sendPasswordResetEmail(email)
                                            .addOnSuccessListener {
                                                isLoading = false
                                                infoMessage = "Recovery link dispatched. Please check your spam folder or inbox."
                                            }
                                            .addOnFailureListener {
                                                isLoading = false
                                                errorMessage = "Dispatch failed: ${it.localizedMessage}"
                                            }
                                    } else {
                                        isLoading = false
                                        errorMessage = "Firebase currently unavailable."
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                tag = "recovery_submit_btn"
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            Text(
                                text = "Back to Sign In",
                                color = ChampagneGold,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clickable {
                                        currentTab = AuthTab.SIGN_IN
                                        errorMessage = null
                                        infoMessage = null
                                    }
                                    .padding(8.dp)
                            )
                        }
                    }
                }
            }

            // Bottom Switcher Toggles (only for Sign In / Sign Up tabs)
            if (currentTab == AuthTab.SIGN_IN || currentTab == AuthTab.SIGN_UP) {
                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = if (currentTab == AuthTab.SIGN_IN) {
                        "New to Svāra? Create an Account"
                    } else {
                        "Already have an account? Sign In"
                    },
                    color = ChampagneGold,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .clickable {
                            currentTab = if (currentTab == AuthTab.SIGN_IN) {
                                AuthTab.SIGN_UP
                            } else {
                                AuthTab.SIGN_IN
                            }
                            errorMessage = null
                            infoMessage = null
                        }
                        .padding(8.dp)
                        .testTag("toggle_auth_state")
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
