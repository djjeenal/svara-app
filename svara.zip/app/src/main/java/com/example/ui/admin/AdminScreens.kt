package com.example.ui.admin

import android.media.MediaPlayer
import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.lib.auth.UserRole
import com.example.lib.firebase.FirebaseManager
import com.example.ui.components.SvaraGoldButton
import com.example.ui.components.SvaraOutlineButton
import com.example.ui.components.SvaraStatCard
import com.example.ui.components.SvaraTextField
import com.example.ui.components.SvaraGoldGradient
import com.example.ui.theme.*
import kotlinx.coroutines.delay

// Data class representation for real-time Firestore Ingestion Tracking
data class AdminPendingRelease(
    val id: String,
    val title: String,
    val artist: String,
    val artistUid: String,
    val album: String,
    val coverArtUrl: String,
    val audioUrl: String,
    val duration: String,
    val fileSize: String,
    val format: String,
    val bitrate: String,
    val sampleRate: String,
    val scale: String,
    val genre: String,
    val createdAt: Long,
    val originalSong: String,
    val originalArtist: String,
    val djName: String,
    val bpmRemix: String,
    val permissionProof: String,
    val releaseType: String,
    val versionType: String,
    val isrc: String,
    val upc: String,
    val copyright: String,
    val contributors: String,
    val royaltySplit: String
)

data class UserAccount(val id: String, val name: String, val email: String, val role: String)

@Composable
fun AdminHub(role: UserRole?, initialSubSection: String) {
    // Role protection secure barrier
    if (role == null || (role != UserRole.ADMIN && role != UserRole.SUPER_ADMIN)) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(ObsidianBlack),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = "Access Denied Alert",
                    tint = ErrorRed,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "ACCESS STRICTLY RESTRICTED",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.5.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Your account is not provisioned with Ingestion Moderator or Root Commander permissions.",
                    color = Color.Gray,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
        return
    }

    var subSection by remember { mutableStateOf(initialSubSection) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(horizontal = 20.dp)
            .padding(bottom = 80.dp) // Player spacing
            .testTag("admin_hub_container")
    ) {
        Spacer(modifier = Modifier.height(20.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "AUDIT TERMINAL",
                color = RoyalGold,
                fontSize = 22.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.5.sp
            )

            Box(
                modifier = Modifier
                    .background(CardSurfaceDark, RoundedCornerShape(8.dp))
                    .border(1.dp, BorderGoldGray, RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = subSection.uppercase(),
                    color = ChampagneGold,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Tab selection row
        ScrollableTabRow(
            selectedTabIndex = getAdminTabIndex(subSection),
            containerColor = Color.Transparent,
            contentColor = RoyalGold,
            edgePadding = 0.dp,
            divider = {},
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[getAdminTabIndex(subSection)]),
                    color = RoyalGold
                )
            }
        ) {
            listOf("dashboard", "approvals", "featured", "users").forEach { tab ->
                Tab(
                    selected = subSection == tab,
                    onClick = { subSection = tab },
                    text = {
                        Text(
                            text = tab.uppercase(),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        when (subSection) {
            "dashboard" -> AdminDashboard()
            "approvals" -> AdminApprovals()
            "featured" -> AdminFeatured()
            "users" -> AdminUsers()
            else -> AdminDashboard()
        }
    }
}

private fun getAdminTabIndex(subSection: String): Int {
    return when (subSection) {
        "dashboard" -> 0
        "approvals" -> 1
        "featured" -> 2
        "users" -> 3
        else -> 0
    }
}

@Composable
fun AdminDashboard() {
    val scroll = rememberScrollState()
    var pendingCount by remember { mutableStateOf(0) }

    LaunchedEffect(Unit) {
        if (FirebaseManager.isServiceReady()) {
            FirebaseManager.firestore.collection("releases")
                .whereEqualTo("status", "pending_review")
                .addSnapshotListener { snap, _ ->
                    if (snap != null) {
                        pendingCount = snap.size()
                    }
                }
        }
    }

    Column(modifier = Modifier.verticalScroll(scroll)) {
        Text(
            text = "Moderation Overview",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp
        )
        Text(
            text = "Review critical ingestion queues and catalog health in real-time.",
            color = Color.Gray,
            fontSize = 13.sp,
            modifier = Modifier.padding(top = 2.dp, bottom = 20.dp)
        )

        SvaraStatCard(
            title = "PENDING RELEASES INGESTION",
            value = "$pendingCount items",
            percentage = "Real-time sync active",
            isPositive = true
        )
        Spacer(modifier = Modifier.height(12.dp))
        SvaraStatCard(
            title = "ACTIVE SYSTEM COMPOSERS",
            value = "89 creators",
            percentage = "+12% this week",
            isPositive = true
        )
        Spacer(modifier = Modifier.height(12.dp))
        SvaraStatCard(
            title = "BANDWIDTH STORAGE ALLOCATED",
            value = "1.24 TB",
            percentage = "Cloudinary capacity okay",
            isPositive = false
        )
    }
}

@Composable
fun AdminApprovals() {
    val context = LocalContext.current
    var pendingReleases by remember { mutableStateOf<List<AdminPendingRelease>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    // Dialog triggering states
    var selectedReleaseForReview by remember { mutableStateOf<AdminPendingRelease?>(null) }

    // Establish dynamic real-time Firestore Listener
    DisposableEffect(Unit) {
        if (!FirebaseManager.isServiceReady()) {
            isLoading = false
            onDispose {}
        }

        val listener = FirebaseManager.firestore.collection("releases")
            .whereIn("status", listOf("pending_review", "PENDING_REVIEW"))
            .addSnapshotListener { snapshot, error ->
                isLoading = false
                if (error != null) {
                    Log.e("AdminApprovals", "Error fetching pending reviews", error)
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val list = snapshot.documents.mapNotNull { doc ->
                        val id = doc.id
                        val title = doc.getString("title") ?: "Untitled"
                        val artist = doc.getString("artist") ?: "Unknown Artist"
                        val artistUid = doc.getString("artistUid") ?: ""
                        val album = doc.getString("album") ?: "Single"
                        val coverArtUrl = doc.getString("coverArtUrl") ?: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300"
                        val audioUrl = doc.getString("audioUrl") ?: ""
                        val duration = doc.getString("duration") ?: "03:15"
                        val fileSize = doc.getString("fileSize") ?: "6.4 MB"
                        val format = doc.getString("format") ?: "MP3"
                        val bitrate = doc.getString("bitrate") ?: "320 kbps"
                        val sampleRate = doc.getString("sampleRate") ?: "44,100 Hz"
                        val scale = doc.getString("scale") ?: "Raga Bhairavi"
                        val genre = doc.getString("genre") ?: doc.getString("scale") ?: "Folk Heritage"
                        val createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis()

                        // Extended details / Custom edits prefilled
                        val releaseType = doc.getString("releaseType") ?: "Single"
                        val versionType = doc.getString("versionType") ?: "Original"

                        // Industry fields prefilled or auto-designed nicely
                        val isrcInput = doc.getString("isrc") ?: "SG-SVR-26-${(10000..99999).random()}"
                        val upcInput = doc.getString("upc") ?: "8901234${(100000..999999).random()}"
                        val copyrightInput = doc.getString("copyright") ?: "© 2026 Svara Records Ltd."
                        val contributorsInput = doc.getString("contributors") ?: "$artist, Aman Vyas"
                        val royaltySplitInput = doc.getString("royaltySplit") ?: "Artist (70%), Platform (30%)"

                        // DJ Remix details
                        val originalSongInput = doc.getString("originalSong") ?: "Original of $title"
                        val originalArtistInput = doc.getString("originalArtist") ?: "Vocal Master"
                        val djNameInput = doc.getString("djName") ?: "DJ $artist"
                        val bpmRemixInput = doc.getString("bpm") ?: "128"
                        val permissionProofInput = doc.getString("permissionProof") ?: "Consent Form Signed"

                        AdminPendingRelease(
                            id = id,
                            title = title,
                            artist = artist,
                            artistUid = artistUid,
                            album = album,
                            coverArtUrl = coverArtUrl,
                            audioUrl = audioUrl,
                            duration = duration,
                            fileSize = fileSize,
                            format = format,
                            bitrate = bitrate,
                            sampleRate = sampleRate,
                            scale = scale,
                            genre = genre,
                            createdAt = createdAt,
                            originalSong = originalSongInput,
                            originalArtist = originalArtistInput,
                            djName = djNameInput,
                            bpmRemix = bpmRemixInput,
                            permissionProof = permissionProofInput,
                            releaseType = releaseType,
                            versionType = versionType,
                            isrc = isrcInput,
                            upc = upcInput,
                            copyright = copyrightInput,
                            contributors = contributorsInput,
                            royaltySplit = royaltySplitInput
                        )
                    }
                    pendingReleases = list.sortedBy { it.createdAt } // oldest first to clear queue fairly
                }
            }

        onDispose {
            listener.remove()
        }
    }

    if (isLoading) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = RoyalGold)
        }
    } else if (pendingReleases.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(vertical = 40.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.DoneAll,
                    contentDescription = "Queue Cleared",
                    tint = SuccessGreen,
                    modifier = Modifier.size(56.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "QUEUE FULLY SCUTTLED",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "No pending songs awaiting human auditing at this moment.",
                    color = Color.Gray,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(pendingReleases, key = { it.id }) { release ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedReleaseForReview = release },
                    colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
                    border = BorderStroke(1.dp, BorderGoldGray)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(
                            model = release.coverArtUrl,
                            contentDescription = "${release.title} cover icon",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(64.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .border(1.dp, BorderGoldGray, RoundedCornerShape(8.dp))
                        )

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = release.title,
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 15.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )

                            Text(
                                text = "by ${release.artist}",
                                color = ChampagneGold,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .background(Color.White.copy(alpha = 0.08f), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = release.genre.uppercase(),
                                        color = Color.LightGray,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Text(
                                    text = "• Ingested: ${formatMillisToDateString(release.createdAt)}",
                                    color = Color.Gray,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        IconButton(
                            onClick = { selectedReleaseForReview = release },
                            modifier = Modifier
                                .size(48.dp)
                                .background(RoyalGold.copy(alpha = 0.15f), RoundedCornerShape(24.dp))
                                .border(1.dp, RoyalGold, RoundedCornerShape(24.dp))
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlaylistPlay,
                                contentDescription = "Open Moderation Deck",
                                tint = RoyalGold
                            )
                        }
                    }
                }
            }
        }
    }

    // Modal Sheet Trigger
    selectedReleaseForReview?.let { release ->
        ReviewReleaseModal(
            release = release,
            onDismiss = { selectedReleaseForReview = null }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReviewReleaseModal(
    release: AdminPendingRelease,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    // Audio Player Preview States
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var rawProgress by remember { mutableStateOf(0f) }
    var totalDurationMs by remember { mutableStateOf(100f) }

    // Forms Edit State pre-filled
    var language by remember { mutableStateOf("Gujarati") }
    var genre by remember { mutableStateOf(release.genre) }
    var selectedReleaseType by remember { mutableStateOf(release.releaseType) }
    var selectedVersionType by remember { mutableStateOf(release.versionType) }

    // Industry Data Section editable state
    var isrc by remember { mutableStateOf(release.isrc) }
    var upc by remember { mutableStateOf(release.upc) }
    var copyright by remember { mutableStateOf(release.copyright) }
    var contributors by remember { mutableStateOf(release.contributors) }
    var royaltySplit by remember { mutableStateOf(release.royaltySplit) }

    // DJ Remix details state
    var originalSong by remember { mutableStateOf(release.originalSong) }
    var originalArtist by remember { mutableStateOf(release.originalArtist) }
    var djName by remember { mutableStateOf(release.djName) }
    var bpmRemix by remember { mutableStateOf(release.bpmRemix) }
    var permissionProof by remember { mutableStateOf(release.permissionProof) }

    // Secondary sub-modals triggers
    var showRejectReasonDialog by remember { mutableStateOf(false) }
    var showRequestChangesDialog by remember { mutableStateOf(false) }

    // Init Preview MediaPlayer
    LaunchedEffect(release.id) {
        if (release.audioUrl.isNotEmpty()) {
            try {
                player?.release()
                player = MediaPlayer().apply {
                    setDataSource(release.audioUrl)
                    setOnPreparedListener { mp ->
                        totalDurationMs = mp.duration.toFloat()
                    }
                    setOnCompletionListener {
                        isPlaying = false
                        rawProgress = 0f
                    }
                    prepareAsync()
                }
            } catch (e: Exception) {
                Log.e("ReviewReleaseModal", "Error initializing player preview", e)
            }
        }
    }

    // Audio time update loop
    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            while (true) {
                val mp = player
                if (mp != null && mp.isPlaying) {
                    rawProgress = mp.currentPosition.toFloat()
                }
                delay(250)
            }
        }
    }

    // Dispose player safely
    DisposableEffect(Unit) {
        onDispose {
            player?.release()
            player = null
        }
    }

    Dialog(
        onDismissRequest = { onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f)
                .border(2.dp, SvaraGoldGradient, RoundedCornerShape(24.dp))
                .clip(RoundedCornerShape(24.dp)),
            color = ObsidianBlack,
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header Block with clear DialogTitle satisfying accessibility
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Gavel,
                            contentDescription = "Audit Status Icon",
                            tint = RoyalGold,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "METADATA AUDIT DECK",
                            color = RoyalGold,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                    }

                    IconButton(
                        onClick = { onDismiss() },
                        modifier = Modifier
                            .size(36.dp)
                            .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(18.dp))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close Audit Details",
                            tint = Color.LightGray,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Scrollable Central Body Containing all 4 Sections
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                ) {
                    // Title Core Detail Hero Header card
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
                        border = BorderStroke(1.dp, BorderGoldGray)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AsyncImage(
                                model = release.coverArtUrl,
                                contentDescription = "Primary Release Artwork Cover zoom",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .border(1.dp, BorderGoldGray, RoundedCornerShape(10.dp))
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text(
                                    text = release.title,
                                    color = Color.White,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 16.sp
                                )
                                Text(
                                    text = "By ${release.artist}",
                                    color = ChampagneGold,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Album: ${release.album}",
                                    color = Color.Gray,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    // REAL AUDIO PREVIEW ENGINE DEEP-ACCORDION
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.White.copy(alpha = 0.03f), RoundedCornerShape(16.dp))
                            .border(1.dp, BorderGoldGray, RoundedCornerShape(16.dp))
                            .padding(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "REAL AUDIO PREVIEW",
                                color = ChampagneGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.5.sp
                            )
                            Icon(Icons.Default.MusicNote, contentDescription = "Ingestion preview", tint = RoyalGold, modifier = Modifier.size(16.dp))
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Progress Control Seeker
                        Slider(
                            value = rawProgress,
                            onValueChange = { seekValue ->
                                rawProgress = seekValue
                                player?.seekTo(seekValue.toInt())
                            },
                            valueRange = 0f..totalDurationMs,
                            colors = SliderDefaults.colors(
                                thumbColor = RoyalGold,
                                activeTrackColor = RoyalGold,
                                inactiveTrackColor = Color.White.copy(alpha = 0.10f)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(24.dp)
                                .testTag("admin_preview_seeker")
                        )

                        // Duration text counters
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            val curSecs = (rawProgress / 1000).toLong()
                            val curMin = curSecs / 60
                            val curSec = curSecs % 60
                            val curFormatted = String.format("%02d:%02d", curMin, curSec)

                            val totSecs = (totalDurationMs / 1000).toLong()
                            val totMin = totSecs / 60
                            val totSec = totSecs % 60
                            val totFormatted = String.format("%02d:%02d", totMin, totSec)

                            Text(curFormatted, color = Color.Gray, fontSize = 11.sp)
                            Text(totFormatted, color = Color.Gray, fontSize = 11.sp)
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Standard Circular transport play button
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center
                        ) {
                            IconButton(
                                onClick = {
                                    val mp = player
                                    if (mp != null) {
                                        if (isPlaying) {
                                            mp.pause()
                                            isPlaying = false
                                        } else {
                                            mp.start()
                                            isPlaying = true
                                        }
                                    } else {
                                        Toast.makeText(context, "Audio source preparative failure.", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier
                                    .size(56.dp) // Minimum 48dp+ accessibility guidelines
                                    .background(SvaraGoldGradient, RoundedCornerShape(28.dp))
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = if (isPlaying) "Pause Track Ingestion" else "Play Track Ingestion",
                                    tint = ObsidianBlack,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // SECTION 1: Basic Info
                    ModerationFormSectionHeader(title = "SECTION 1: BASIC INFO")
                    
                    SvaraTextField(
                        value = language,
                        onValueChange = { language = it },
                        label = "Language Classification"
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    SvaraTextField(
                        value = genre,
                        onValueChange = { genre = it },
                        label = "Genre Tagging"
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "RELEASE TYPE",
                        color = ChampagneGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        listOf("Single", "Album", "EP").forEach { opt ->
                            val selected = selectedReleaseType == opt
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(if (selected) RoyalGold else CardSurfaceDark, RoundedCornerShape(12.dp))
                                    .border(1.dp, if (selected) RoyalGold else BorderGoldGray, RoundedCornerShape(12.dp))
                                    .clickable { selectedReleaseType = opt }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = opt.uppercase(),
                                    color = if (selected) ObsidianBlack else Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "VERSION CATEGORY",
                        color = ChampagneGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        listOf("Original", "DJ Remix", "Live Cover").forEach { opt ->
                            val selected = selectedVersionType == opt
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(if (selected) RoyalGold else CardSurfaceDark, RoundedCornerShape(12.dp))
                                    .border(1.dp, if (selected) RoyalGold else BorderGoldGray, RoundedCornerShape(12.dp))
                                    .clickable { selectedVersionType = opt }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = opt.uppercase(),
                                    color = if (selected) ObsidianBlack else Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // SECTION 2: Metadata read-only fields
                    ModerationFormSectionHeader(title = "SECTION 2: METADATA INFORMATION")
                    MetadataRow(label = "Duration (In File)", value = release.duration)
                    MetadataRow(label = "Raw File Size", value = release.fileSize)
                    MetadataRow(label = "Codec/Format", value = release.format)
                    MetadataRow(label = "Encoding Bitrate", value = release.bitrate)
                    MetadataRow(label = "Acoustic Sample Rate", value = release.sampleRate)

                    Spacer(modifier = Modifier.height(20.dp))

                    // SECTION 3: Industry Data
                    ModerationFormSectionHeader(title = "SECTION 3: GLOBAL INDUSTRY METRICS")
                    
                    SvaraTextField(
                        value = isrc,
                        onValueChange = { isrc = it },
                        label = "ISRC Registry Code (International Standard)"
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    SvaraTextField(
                        value = upc,
                        onValueChange = { upc = it },
                        label = "UPC / EAN Product Barcode"
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    SvaraTextField(
                        value = copyright,
                        onValueChange = { copyright = it },
                        label = "Formal Copyright Notice"
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    SvaraTextField(
                        value = contributors,
                        onValueChange = { contributors = it },
                        label = "Key Editorial Contributors (Separated by Comma)"
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    SvaraTextField(
                        value = royaltySplit,
                        onValueChange = { royaltySplit = it },
                        label = "Fiduciary Royalty Allocation Plan"
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // Dynamic Section 4: DJ Remix (smoothly reactive to version)
                    if (selectedVersionType == "DJ Remix") {
                        ModerationFormSectionHeader(title = "SECTION 4: COMPREHENSIVE DJ REMIX METRICS")
                        
                        SvaraTextField(
                            value = originalSong,
                            onValueChange = { originalSong = it },
                            label = "Original Target Track Title"
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        SvaraTextField(
                            value = originalArtist,
                            onValueChange = { originalArtist = it },
                            label = "Original Composer / Artist"
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        SvaraTextField(
                            value = djName,
                            onValueChange = { djName = it },
                            label = "Performing Remix DJ Stage Name"
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        SvaraTextField(
                            value = bpmRemix,
                            onValueChange = { bpmRemix = it },
                            label = "Tempo Speed (BPM Beats-Per-Minute)"
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        SvaraTextField(
                            value = permissionProof,
                            onValueChange = { permissionProof = it },
                            label = "Clearance Verification Status / Proof Contract"
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                    }
                }

                // Interactive Primary Moderation Action Buttons Footer Ingress
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SvaraOutlineButton(
                            text = "REJECT",
                            onClick = { showRejectReasonDialog = true },
                            modifier = Modifier
                                .weight(1f)
                                .height(56.dp)
                        )
                        
                        SvaraOutlineButton(
                            text = "CHG STATUS",
                            onClick = { showRequestChangesDialog = true },
                            modifier = Modifier
                                .weight(1f)
                                .height(56.dp)
                        )
                    }

                    // Huge Gold Approve Button - 56dp+ height accessibility
                    Button(
                        onClick = {
                            val db = FirebaseManager.firestore
                            val updateMap = hashMapOf(
                                "status" to "live",
                                "approvedAt" to System.currentTimeMillis(),
                                "approvedBy" to (FirebaseManager.auth.currentUser?.uid ?: "sys_admin"),
                                "language" to language,
                                "genre" to genre,
                                "releaseType" to selectedReleaseType,
                                "versionType" to selectedVersionType,
                                "isrc" to isrc,
                                "upc" to upc,
                                "copyright" to copyright,
                                "contributors" to contributors,
                                "royaltySplit" to royaltySplit,
                                "originalSong" to originalSong,
                                "originalArtist" to originalArtist,
                                "djName" to djName,
                                "bpm" to bpmRemix,
                                "permissionProof" to permissionProof
                            )

                            // 1. Transactional Update "releases" status
                            db.collection("releases").document(release.id).update(updateMap as Map<String, Any>)
                                .addOnSuccessListener {
                                    // 2. Clone/Index into public "songs" database search inventory
                                    val songPayload = hashMapOf(
                                        "title" to release.title,
                                        "artist" to release.artist,
                                        "coverArtUrl" to release.coverArtUrl, // both field conventions
                                        "coverUrl" to release.coverArtUrl,
                                        "audioUrl" to release.audioUrl,
                                        "duration" to release.duration,
                                        "genre" to genre,
                                        "language" to language,
                                        "isrc" to isrc,
                                        "upc" to upc,
                                        "contributors" to contributors,
                                        "verified" to true,
                                        "createdAt" to System.currentTimeMillis()
                                    )

                                    db.collection("songs").add(songPayload)
                                        .addOnSuccessListener {
                                            Toast.makeText(context, "Clearance status updated. Release is instantly LIVE publicly!", Toast.LENGTH_LONG).show()
                                            player?.stop()
                                            onDismiss()
                                        }
                                        .addOnFailureListener { e ->
                                            Toast.makeText(context, "Releases set live, but public song catalog write failed: ${e.message}", Toast.LENGTH_LONG).show()
                                        }
                                }
                                .addOnFailureListener { e ->
                                    Toast.makeText(context, "Failed to update status: ${e.message}", Toast.LENGTH_LONG).show()
                                }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent, contentColor = ObsidianBlack),
                        shape = RoundedCornerShape(28.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .border(1.dp, SvaraGoldGradient, RoundedCornerShape(28.dp))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(SvaraGoldGradient),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "APPROVE INTEGRATE RELEASE",
                                color = ObsidianBlack,
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp,
                                letterSpacing = 1.sp
                            )
                        }
                    }
                }
            }
        }
    }

    // SECTION 5: SECONDARY DIALOGS - REJECT SYSTEM (with DialogTitle support)
    if (showRejectReasonDialog) {
        var selectedReason by remember { mutableStateOf("Copyright Issue") }
        var isSubmitting by remember { mutableStateOf(false) }

        val rejectReasons = listOf(
            "Copyright Issue",
            "Poor Audio Quality",
            "Wrong Metadata",
            "Duplicate Release",
            "Policy Violation",
            "Low Quality Artwork",
            "Other"
        )

        AlertDialog(
            onDismissRequest = { showRejectReasonDialog = false },
            title = {
                Text(
                    text = "SPECIFY REJECTION AUDIT CAUSE",
                    color = ErrorRed,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        "Please select the fatal error reason for rejecting this release. This action notifies the deployment creator.",
                        color = Color.LightGray,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    rejectReasons.forEach { reason ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedReason = reason }
                                .padding(vertical = 4.dp)
                        ) {
                            RadioButton(
                                selected = selectedReason == reason,
                                onClick = { selectedReason = reason },
                                colors = RadioButtonDefaults.colors(
                                    selectedColor = RoyalGold,
                                    unselectedColor = Color.Gray
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = reason, color = Color.White, fontSize = 14.sp)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (isSubmitting) return@Button
                        isSubmitting = true
                        val db = FirebaseManager.firestore
                        db.collection("releases").document(release.id).update(
                            mapOf(
                                "status" to "rejected",
                                "rejectionReason" to selectedReason,
                                "rejectedAt" to System.currentTimeMillis()
                            )
                        ).addOnSuccessListener {
                            Toast.makeText(context, "Ingestion rejected: $selectedReason", Toast.LENGTH_SHORT).show()
                            isSubmitting = false
                            showRejectReasonDialog = false
                            player?.stop()
                            onDismiss()
                        }.addOnFailureListener { e ->
                            Toast.makeText(context, "Database failed: ${e.message}", Toast.LENGTH_SHORT).show()
                            isSubmitting = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorRed, contentColor = Color.White)
                ) {
                    Text("REJECT INGESTION", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRejectReasonDialog = false }) {
                    Text("CANCEL", color = Color.Gray)
                }
            },
            containerColor = CardSurfaceDark,
            tonalElevation = 8.dp
        )
    }

    // SECTION 6: SECONDARY DIALOGS - REQUEST CHANGES (with DialogTitle support)
    if (showRequestChangesDialog) {
        var adminFeedback by remember { mutableStateOf("Please improve cover quality") }
        var isSubmitting by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showRequestChangesDialog = false },
            title = {
                Text(
                    text = "CORRECTIVE ACTION REQUEST",
                    color = RoyalGold,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = "Specify constructive feedback pointing out the exact changes requested (required):",
                        color = Color.LightGray,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    SvaraTextField(
                        value = adminFeedback,
                        onValueChange = { adminFeedback = it },
                        label = "Moderator Correction Message",
                        placeholder = "e.g. Please improve cover quality or crop art"
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (adminFeedback.isBlank()) {
                            Toast.makeText(context, "Feedback review description is required.", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        if (isSubmitting) return@Button
                        isSubmitting = true
                        val db = FirebaseManager.firestore
                        db.collection("releases").document(release.id).update(
                            mapOf(
                                "status" to "changes_requested",
                                "adminFeedback" to adminFeedback,
                                "requestedAt" to System.currentTimeMillis()
                            )
                        ).addOnSuccessListener {
                            Toast.makeText(context, "Feedback dispatched to artist portfolio.", Toast.LENGTH_SHORT).show()
                            isSubmitting = false
                            showRequestChangesDialog = false
                            player?.stop()
                            onDismiss()
                        }.addOnFailureListener { e ->
                            Toast.makeText(context, "Database failed: ${e.message}", Toast.LENGTH_SHORT).show()
                            isSubmitting = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalGold, contentColor = ObsidianBlack)
                ) {
                    Text("SUBMIT CORRECTION", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRequestChangesDialog = false }) {
                    Text("CANCEL", color = Color.Gray)
                }
            },
            containerColor = CardSurfaceDark,
            tonalElevation = 8.dp
        )
    }
}

@Composable
fun ModerationFormSectionHeader(title: String) {
    Text(
        text = title,
        color = RoyalGold,
        fontSize = 12.sp,
        fontWeight = FontWeight.Black,
        letterSpacing = 1.sp,
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 16.dp, bottom = 8.dp)
            .border(
                width = 1.dp,
                brush = Brush.horizontalGradient(listOf(RoyalGold.copy(alpha = 0.4f), Color.Transparent)),
                shape = RoundedCornerShape(0.dp)
            )
            .padding(bottom = 4.dp)
    )
}

@Composable
fun MetadataRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = Color.Gray, fontSize = 12.sp)
        Text(text = value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}

private fun formatMillisToDateString(millis: Long): String {
    val sdf = java.text.SimpleDateFormat("MMM dd, yyyy", java.util.Locale.getDefault())
    return sdf.format(java.util.Date(millis))
}

@Composable
fun AdminFeatured() {
    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text(
            text = "FEATURED DECK ORGANIZER",
            color = ChampagneGold,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
            border = BorderStroke(1.dp, BorderGoldGray)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Carousel Spotlight: Slot #1", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("Current Active: Rang Rasiya Garba Series", color = RoyalGold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(12.dp))
                SvaraOutlineButton(
                    text = "REASSIGN SPOTLIGHT SLOT",
                    onClick = {}
                )
            }
        }
    }
}

@Composable
fun AdminUsers() {
    val usersList = listOf(
        UserAccount("1", "Aman Vyas", "aman.vyas@svara.app", "ARTIST"),
        UserAccount("2", "Dj Jeenal", "djjeenal@gmail.com", "ADMIN"),
        UserAccount("3", "Mehul Shah", "mehul@gmail.com", "USER")
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxWidth()
            .height(400.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(usersList) { u ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CardSurfaceDark, RoundedCornerShape(8.dp))
                    .border(1.dp, BorderGoldGray, RoundedCornerShape(8.dp))
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = u.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(text = u.email, color = Color.Gray, fontSize = 12.sp)
                }

                Box(
                    modifier = Modifier
                        .background(RoyalGold, RoundedCornerShape(4.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(text = u.role, color = ObsidianBlack, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }
    }
}
