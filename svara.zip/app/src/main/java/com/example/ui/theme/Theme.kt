package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val SvaraColorScheme = darkColorScheme(
    primary = RoyalGold,
    onPrimary = ObsidianBlack,
    primaryContainer = BorderGoldGray,
    onPrimaryContainer = ChampagneGold,
    secondary = ChampagneGold,
    onSecondary = ObsidianBlack,
    secondaryContainer = CardSurfaceDark,
    onSecondaryContainer = RichGold,
    tertiary = MutedGold,
    onTertiary = ObsidianBlack,
    background = ObsidianBlack,
    onBackground = Color.White,
    surface = CardSurfaceDark,
    onSurface = Color.White,
    surfaceVariant = CharcoalDark,
    onSurfaceVariant = slateGaryOrWhite(),
    outline = BorderGoldGray,
    error = ErrorRed,
    onError = Color.White
)

private fun slateGaryOrWhite(): Color = Color(0xFFB5BAC0)

@Composable
fun SvaraTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = SvaraColorScheme,
        typography = Typography,
        content = content
    )
}
