package com.example.ui.home

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.lib.audio.AudioPlayerManager
import com.example.lib.audio.Track
import com.example.ui.components.SvaraGoldGradient
import com.example.ui.components.SvaraSectionHeader
import com.example.ui.components.SvaraTrackCard
import com.example.ui.theme.*

@Composable
fun HomeScreen(
    onTrackSelect: (Track) -> Unit,
    onNavigateToPlayer: () -> Unit
) {
    val tracks by AudioPlayerManager.allAvailableTracks.collectAsState()
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .verticalScroll(scrollState)
            .padding(bottom = 80.dp) // Spacing for bottom floating player bar
            .testTag("home_screen_feed")
    ) {
        // Luxury Welcome Branding
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Welcome to",
                    color = Color.Gray,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Svāra Premium",
                    color = RoyalGold,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif
                )
            }
            Icon(
                imageVector = Icons.Default.WorkspacePremium,
                contentDescription = "Premium Badge",
                tint = RichGold,
                modifier = Modifier.size(28.dp)
            )
        }

        // Genre Chips (from Sophisticated Dark design)
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(horizontal = 24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp)
        ) {
            item {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(RoyalGold)
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = "For You",
                        color = ObsidianBlack,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
            listOf("Gazals", "Folk", "Sugam", "Garba", "Classical").forEach { genre ->
                item {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .border(1.dp, BorderGoldGray, RoundedCornerShape(50))
                            .background(Color.Transparent)
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = genre,
                            color = Color.White.copy(alpha = 0.6f),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Hero Spotlight Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .padding(horizontal = 24.dp)
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, SvaraGoldGradient, RoundedCornerShape(16.dp))
        ) {
            // Visual Banner Artwork
            AsyncImage(
                model = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600",
                contentDescription = "Spotlight Album Art",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // Multi-Layer luxury visual overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.9f))
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.Bottom
            ) {
                Box(
                    modifier = Modifier
                        .background(SvaraGoldGradient, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "NEW SUR",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = ObsidianBlack
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Rang Rasiya Garba Series",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Experience authentic Gujarati roots featuring Falguni Dave",
                    color = Color.LightGray,
                    fontSize = 12.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Svāra Heritage Gems (Traditional Track Carousel)
        Column(modifier = Modifier.padding(horizontal = 24.dp)) {
            SvaraSectionHeader(
                title = "Heritage Gems",
                subtitle = "Handcrafted Gujarati tracks for the refined ear"
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(tracks) { track ->
                    SvaraTrackCard(
                        title = track.title,
                        artist = track.artist,
                        coverUrl = track.coverArtUrl,
                        onClick = { onTrackSelect(track) }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Daily Golden Playlists
        Column(modifier = Modifier.padding(horizontal = 24.dp)) {
            SvaraSectionHeader(
                title = "Golden Playlists",
                subtitle = "Curated collections with regional focus"
            )

            // Grid items
            listOf(
                "Mitti Na Sura" to "Soul-stirring folk classical strings",
                "Navratri Heritage" to "High-energy dhol and traditional garba",
                "Kutchi Beats" to "Lively tunes from the salt deserts of Kutch"
            ).forEach { (pTitle, pDesc) ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                        .clickable {
                            if (tracks.isNotEmpty()) {
                                onTrackSelect(tracks[0])
                            }
                        },
                    colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, BorderGoldGray)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(SvaraGoldGradient),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = ObsidianBlack)
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = pTitle,
                                color = ChampagneGold,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = pDesc,
                                color = Color.Gray,
                                fontSize = 12.sp,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }
    }
}
