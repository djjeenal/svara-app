package com.example.ui.navigation

/**
 * Clean catalog of system-wide destinations matching Next.js folder schemas
 * and translating them directly into native Jetpack Compose screen tokens.
 */
enum class SvaraScreen(val route: String, val title: String) {
    // Auth Flow
    AUTH("auth", "Auth Portal"),

    // Consumer (Listener) Flow
    HOME("home", "Svāra Home"),
    SEARCH("search", "Discover Sounds"),
    LIBRARY("library", "Personal Safekeeping"),
    PLAYER("player", "Premium Audio Controller"),

    // Content Creator / Artist Portal
    ARTIST_DASHBOARD("artist/dashboard", "Artist Overview"),
    ARTIST_UPLOAD("artist/upload", "Deploy Tracks"),
    ARTIST_RELEASES("artist/releases", "Releases Archive"),
    ARTIST_ANALYTICS("artist/analytics", "Insights & Streams"),
    ARTIST_SETTINGS("artist/settings", "Creator Profile"),

    // Executive Administrative Dashboard
    ADMIN_DASHBOARD("admin/dashboard", "Console Dashboard"),
    ADMIN_APPROVALS("admin/approvals", "Validate Release Ingress"),
    ADMIN_FEATURED("admin/featured", "Visual & Audio Curation"),
    ADMIN_USERS("admin/users", "Identity Roles"),

    // Super Admin Gateway
    SUPER_ADMIN("super-admin", "Master Cluster Status")
}
