package com.example.ui.player

import android.widget.Toast
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.lib.audio.AudioPlayerManager
import com.example.lib.audio.RepeatMode
import com.example.lib.audio.Track
import com.example.ui.components.SvaraGoldGradient
import com.example.ui.theme.*

@Composable
fun PlayerScreen(
    onBackClick: () -> Unit = {}
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    // State flows
    val currentTrack by AudioPlayerManager.currentTrack.collectAsState()
    val isPlaying by AudioPlayerManager.isPlaying.collectAsState()
    val isLoading by AudioPlayerManager.isLoading.collectAsState()
    val playbackError by AudioPlayerManager.playbackError.collectAsState()
    val progress by AudioPlayerManager.playbackProgress.collectAsState()
    val elapsedSeconds by AudioPlayerManager.currentSeconds.collectAsState()
    val queue by AudioPlayerManager.queue.collectAsState()
    val isShuffle by AudioPlayerManager.isShuffle.collectAsState()
    val repeatMode by AudioPlayerManager.repeatMode.collectAsState()
    val likedTrackIds by AudioPlayerManager.likedTrackIds.collectAsState()

    // Dialog sheets states
    var showShareDialog by remember { mutableStateOf(false) }
    var showDownloadDialog by remember { mutableStateOf(false) }
    var showQueueDrawer by remember { mutableStateOf(false) }
    var showPlaylistDialog by remember { mutableStateOf(false) }

    val track = currentTrack ?: return

    val totalDurationStr = formatTime(track.durationSeconds)
    val elapsedStr = formatTime(elapsedSeconds)

    // Pulsing artwork scale animation for active playback status
    val infiniteTransition = rememberInfiniteTransition(label = "PulseBackground")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isPlaying) 1.04f else 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Reverse
        ),
        label = "GlowScale"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .testTag("full_player_screen")
    ) {
        // Blur cover backdrop for premium ambient layout
        AsyncImage(
            model = track.coverArtUrl,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            alpha = 0.12f,
            modifier = Modifier.fillMaxSize()
        )

        // Main layout scroll container (Android-First responsive padding)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Elegant embedded Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("player_back_arrow")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Exit Player",
                        tint = RoyalGold,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "SVĀRA AUDITORIUM",
                        color = RoyalGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = "Raga Bhairavi Mode • 24-bit Hi-Fi",
                        color = Color.Gray,
                        fontSize = 9.sp,
                        letterSpacing = 0.5.sp
                    )
                }

                IconButton(
                    onClick = { showShareDialog = true },
                    modifier = Modifier.size(48.dp).testTag("player_share_action")
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Share Composition",
                        tint = ChampagneGold,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            // Central scrollable region to prevent clipping on small handheld screens
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(12.dp))

                // Premium Glowing Cover Artwork Poster
                Box(
                    modifier = Modifier
                        .scale(pulseScale)
                        .size(300.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(CardSurfaceDark)
                        .border(
                            BorderStroke(
                                if (isPlaying) 2.5.dp else 1.dp,
                                if (isPlaying) SvaraGoldGradient else Brush.linearGradient(listOf(BorderGoldGray, BorderGoldGray))
                            ),
                            RoundedCornerShape(24.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    AsyncImage(
                        model = track.coverArtUrl,
                        contentDescription = "Cover Poster Artwork",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Loading overlay indicator
                    if (isLoading) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = 0.65f)),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = RoyalGold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(28.dp))

                // Metadata Details: Title, Artists, Subtitles
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = track.title,
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            fontFamily = FontFamily.Serif
                        )
                        Spacer(modifier = Modifier.height(4.dp))

                        // Clickable Artist name
                        Text(
                            text = track.artist,
                            color = ChampagneGold,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .clickable {
                                    Toast.makeText(context, "${track.artist} is a prominent Classical vocalist of Gujarat.", Toast.LENGTH_LONG).show()
                                }
                                .padding(vertical = 2.dp)
                        )

                        // Featuring artists labels
                        if (!track.featuringArtists.isNullOrEmpty()) {
                            Text(
                                text = "Featuring: ${track.featuringArtists}",
                                color = Color.Gray,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    // Like/Favorite button synced to firestore
                    val isLiked = likedTrackIds.contains(track.id)
                    IconButton(
                        onClick = { AudioPlayerManager.toggleLikeTrack(track, context) },
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("player_favorite_action")
                    ) {
                        Icon(
                            imageVector = if (isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Favorite track",
                            tint = if (isLiked) ErrorRed else Color.LightGray,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                // Error State Feedback Indicator
                if (!playbackError.isNullOrEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = playbackError ?: "",
                        color = ErrorRed,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                } else if (isLoading) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Preparing audio...",
                        color = ChampagneGold,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Custom Premium Real Seek Bar
                Column(modifier = Modifier.fillMaxWidth()) {
                    Slider(
                        value = progress,
                        onValueChange = { AudioPlayerManager.seekToFraction(it) },
                        colors = SliderDefaults.colors(
                            thumbColor = RoyalGold,
                            activeTrackColor = RoyalGold,
                            inactiveTrackColor = BorderGoldGray
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("player_progress_slider")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = elapsedStr,
                            color = Color.LightGray,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = totalDurationStr,
                            color = Color.LightGray,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Fully Interactive Control Deck with 56px+ Touch targets
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Shuffle Toggle
                    IconButton(
                        onClick = { AudioPlayerManager.setShuffle(!isShuffle) },
                        modifier = Modifier
                            .size(56.dp)
                            .testTag("player_shuffle_action")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shuffle,
                            contentDescription = "Shuffle Songs",
                            tint = if (isShuffle) RoyalGold else Color.Gray,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    // Skip Previous
                    IconButton(
                        onClick = { AudioPlayerManager.previousTrack() },
                        modifier = Modifier
                            .size(56.dp)
                            .testTag("player_skip_back")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipPrevious,
                            contentDescription = "Previous Song",
                            tint = Color.White,
                            modifier = Modifier.size(34.dp)
                        )
                    }

                    // Main circular playback bubble
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(SvaraGoldGradient)
                            .clickable { AudioPlayerManager.togglePlayback() }
                            .testTag("player_play_pause_fab"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Toggle play pause",
                            tint = ObsidianBlack,
                            modifier = Modifier.size(34.dp)
                        )
                    }

                    // Skip Next
                    IconButton(
                        onClick = { AudioPlayerManager.nextTrack() },
                        modifier = Modifier
                            .size(56.dp)
                            .testTag("player_skip_forward")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipNext,
                            contentDescription = "Next Song",
                            tint = Color.White,
                            modifier = Modifier.size(34.dp)
                        )
                    }

                    // Repeat Mode Cycler
                    IconButton(
                        onClick = { AudioPlayerManager.cycleRepeatMode() },
                        modifier = Modifier
                            .size(56.dp)
                            .testTag("player_repeat_action")
                    ) {
                        val tintColor = if (repeatMode != com.example.lib.audio.RepeatMode.NONE) RoyalGold else Color.Gray
                        val icon = when (repeatMode) {
                            com.example.lib.audio.RepeatMode.ONE -> Icons.Default.RepeatOne
                            else -> Icons.Default.Repeat
                        }
                        Icon(
                            imageVector = icon,
                            contentDescription = "Cycle Repeat Mode",
                            tint = tintColor,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Row for Extra Actions (Add Playlist, Replay/Restart, Queue, Download)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Replay / Rewind Track to 0
                    IconButton(
                        onClick = { AudioPlayerManager.replay() },
                        modifier = Modifier.size(52.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Replay, contentDescription = "Restart Song", tint = ChampagneGold, modifier = Modifier.size(20.dp))
                            Text("Replay", color = Color.Gray, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Add to Playlist button
                    IconButton(
                        onClick = { showPlaylistDialog = true },
                        modifier = Modifier.size(52.dp).testTag("player_add_playlist_action")
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.PlaylistAdd, contentDescription = "Add to playlist", tint = ChampagneGold, modifier = Modifier.size(20.dp))
                            Text("Playlist", color = Color.Gray, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // View Next Queue System
                    IconButton(
                        onClick = { showQueueDrawer = !showQueueDrawer },
                        modifier = Modifier.size(52.dp).testTag("player_view_queue_action")
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.QueueMusic, contentDescription = "Open Playback Queue", tint = if (showQueueDrawer) RoyalGold else ChampagneGold, modifier = Modifier.size(20.dp))
                            Text("Queue", color = Color.Gray, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Premium Ready Download
                    IconButton(
                        onClick = { showDownloadDialog = true },
                        modifier = Modifier.size(52.dp).testTag("player_download_action")
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.CloudDownload, contentDescription = "Download Music", tint = ChampagneGold, modifier = Modifier.size(20.dp))
                            Text("Download", color = Color.Gray, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Unified Expandable Queue Drawer (Section: Playing Next)
                if (showQueueDrawer) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp)
                            .border(1.dp, BorderGoldGray, RoundedCornerShape(16.dp)),
                        colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "PLAYING NEXT",
                                    color = ChampagneGold,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.5.sp
                                )
                                Text(
                                    text = "${queue.size} Tracks",
                                    color = Color.Gray,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))

                            if (queue.isEmpty() || queue.size <= 1) {
                                Text(
                                    text = "End of Playback queue. Add songs from Discovery.",
                                    color = Color.Gray,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(vertical = 8.dp)
                                )
                            } else {
                                queue.filter { it.id != track.id }.forEachIndexed { index, queueTrack ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 6.dp)
                                            .clickable {
                                                AudioPlayerManager.playTrack(queueTrack)
                                            },
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        AsyncImage(
                                            model = queueTrack.coverArtUrl,
                                            contentDescription = "Queue Art",
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(Color.Gray)
                                        )

                                        Spacer(modifier = Modifier.width(10.dp))

                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = queueTrack.title,
                                                color = Color.White,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = queueTrack.artist,
                                                color = Color.Gray,
                                                fontSize = 10.sp,
                                                maxLines = 1
                                            )
                                        }

                                        // Support Re-order indices or instant remove button
                                        IconButton(
                                            onClick = {
                                                AudioPlayerManager.removeFromQueue(queueTrack.id)
                                                Toast.makeText(context, "Track deleted from playing next queue", Toast.LENGTH_SHORT).show()
                                            },
                                            modifier = Modifier.size(36.dp)
                                        ) {
                                            Icon(Icons.Default.RemoveCircleOutline, contentDescription = "Delete from queue", tint = ErrorRed, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }

    // Modal Sheet 1: Share Composition Drawer
    if (showShareDialog) {
        AlertDialog(
            onDismissRequest = { showShareDialog = false },
            title = {
                Text(
                    text = "SHARE WORK",
                    color = RoyalGold,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Serif
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(
                        text = "Broadcast '${track.title}' to your social circles. Copy high-fidelity dynamic URLs directly.",
                        color = Color.LightGray,
                        fontSize = 12.sp
                    )
                    Divider(color = BorderGoldGray)

                    // Share WhatsApp
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                showShareDialog = false
                                Toast.makeText(context, "Redirecting to WhatsApp to share ${track.title}...", Toast.LENGTH_SHORT).show()
                            }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Share, contentDescription = "WhatsApp", tint = SuccessGreen)
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(text = "Share on WhatsApp", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }

                    // Share Instagram
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                showShareDialog = false
                                Toast.makeText(context, "Sharing track preview on Instagram Stories...", Toast.LENGTH_SHORT).show()
                            }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.PhotoCamera, contentDescription = "Instagram", tint = RichGold)
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(text = "Share on Instagram Stories", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }

                    // Copy Link option
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                showShareDialog = false
                                val shareUrl = "https://svara.music/track/${track.id}"
                                clipboardManager.setText(AnnotatedString(shareUrl))
                                Toast.makeText(context, "Svāra Song link copied: $shareUrl", Toast.LENGTH_LONG).show()
                            }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy Link", tint = ChampagneGold)
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(text = "Copy Shareable Link", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showShareDialog = false }) {
                    Text("CLOSE", color = RoyalGold, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = CardSurfaceDark,
            textContentColor = Color.White
        )
    }

    // Modal Sheet 2: Premium Download Choice dialog
    if (showDownloadDialog) {
        AlertDialog(
            onDismissRequest = { showDownloadDialog = false },
            title = {
                Text(
                    text = "DOWNLOAD AUDITORIUM AUDIO",
                    color = RoyalGold,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Serif
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Choose audio stream compression profile for offline local caching. Exclusive to Premium subscribers.",
                        color = Color.LightGray,
                        fontSize = 12.sp
                    )
                    Divider(color = BorderGoldGray)

                    // Choice 1: Low
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                showDownloadDialog = false
                                Toast.makeText(context, "Caching 'Low Quality' MP3 (128kbps) standard track offline...", Toast.LENGTH_LONG).show()
                            },
                        colors = CardDefaults.cardColors(containerColor = ObsidianBlack),
                        border = BorderStroke(1.dp, BorderGoldGray)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Low Quality", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("128 kbps • Compressed, data-friendly", color = Color.Gray, fontSize = 11.sp)
                            }
                            Text("~2.4 MB", color = ChampagneGold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    // Choice 2: High
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                showDownloadDialog = false
                                Toast.makeText(context, "Caching 'High Quality' MP3 (320kbps) studio track offline...", Toast.LENGTH_LONG).show()
                            },
                        colors = CardDefaults.cardColors(containerColor = ObsidianBlack),
                        border = BorderStroke(1.dp, BorderGoldGray)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("High Quality", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("320 kbps • Premium high clarity mp3", color = Color.Gray, fontSize = 11.sp)
                            }
                            Text("~6.0 MB", color = ChampagneGold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    // Choice 3: FLAC Lossless
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                showDownloadDialog = false
                                Toast.makeText(context, "Downloading 'Lossless FLAC' raw studio audio offline...", Toast.LENGTH_LONG).show()
                            },
                        colors = CardDefaults.cardColors(containerColor = ObsidianBlack),
                        border = BorderStroke(1.dp, SvaraGoldGradient)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Lossless Audio (Studio Master)", color = RoyalGold, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("24-bit FLAC • Pure uncompressed classical sur", color = Color.LightGray, fontSize = 11.sp)
                            }
                            Text("~45.2 MB", color = RoyalGold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showDownloadDialog = false }) {
                    Text("CLOSE", color = RoyalGold, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = CardSurfaceDark,
            textContentColor = Color.White
        )
    }

    // Modal Sheet 3: Add to Playlist selection
    if (showPlaylistDialog) {
        AlertDialog(
            onDismissRequest = { showPlaylistDialog = false },
            title = {
                Text(
                    text = "CHOOSE SVĀRA PLAYLIST",
                    color = RoyalGold,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Select a custom collection to append this track directly to.", color = Color.LightGray, fontSize = 12.sp)
                    Divider(color = BorderGoldGray)

                    // Mock list or real Firestore collections sync
                    listOf("Mitti Na Sura Collection", "Evening Raga Highlights", "Folk Gems").forEach { pl ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    showPlaylistDialog = false
                                    Toast.makeText(context, "Appended '${track.title}' to playlist '$pl' successfully!", Toast.LENGTH_SHORT).show()
                                }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.PlaylistPlay, contentDescription = "Playlist", tint = ChampagneGold)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(text = pl, color = Color.White, fontSize = 14.sp)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showPlaylistDialog = false }) {
                    Text("CANCEL", color = RoyalGold)
                }
            },
            containerColor = CardSurfaceDark
        )
    }
}

private fun formatTime(seconds: Int): String {
    val m = seconds / 60
    val s = seconds % 60
    return String.format("%02d:%02d", m, s)
}
