package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.theme.*

// Premium Gold Gradient Brush representing Royal and Champagne gold
val SvaraGoldGradient = Brush.linearGradient(
    colors = listOf(RoyalGold, ChampagneGold, DarkBronze)
)

val ObsidianGradient = Brush.verticalGradient(
    colors = listOf(ObsidianBlack, CharcoalDark, PureBlack)
)

@Composable
fun SvaraGoldButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    tag: String = "svara_gold_button"
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.Transparent,
            contentColor = ObsidianBlack
        ),
        contentPadding = PaddingValues(0.dp), // handle gradient padding
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
            .testTag(tag)
            .height(50.dp)
            .border(1.dp, SvaraGoldGradient, RoundedCornerShape(8.dp))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(SvaraGoldGradient)
                .padding(horizontal = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = text,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                fontFamily = FontFamily.SansSerif,
                color = ObsidianBlack
            )
        }
    }
}

@Composable
fun SvaraOutlineButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    tag: String = "svara_outline_button"
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(8.dp),
        border = if (enabled) BorderStroke(1.dp, SvaraGoldGradient) else BorderStroke(1.dp, Color.Gray.copy(alpha = 0.3f)),
        colors = ButtonDefaults.outlinedButtonColors(
            contentColor = if (enabled) RoyalGold else Color.Gray,
            containerColor = Color.Transparent
        ),
        modifier = modifier
            .testTag(tag)
            .height(50.dp)
    ) {
        Text(
            text = text,
            fontWeight = FontWeight.SemiBold,
            color = if (enabled) ChampagneGold else Color.Gray,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun SvaraTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    placeholder: String = "",
    leadingIcon: @Composable (() -> Unit)? = null,
    trailingIcon: @Composable (() -> Unit)? = null,
    tag: String = "svara_textfield"
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, color = MutedGold) },
        placeholder = { Text(placeholder, color = Color.Gray) },
        leadingIcon = leadingIcon,
        trailingIcon = trailingIcon,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = RoyalGold,
            unfocusedBorderColor = BorderGoldGray,
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            focusedContainerColor = CardSurfaceDark,
            unfocusedContainerColor = CardSurfaceDark,
            cursorColor = RoyalGold
        ),
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag(tag)
    )
}

@Composable
fun SvaraSectionHeader(
    title: String,
    subtitle: String? = null,
    showViewAll: Boolean = true,
    onViewAllClick: () -> Unit = {}
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Bottom
    ) {
        Column {
            Text(
                text = title.uppercase(),
                style = MaterialTheme.typography.titleMedium.copy(
                    color = ActionGoldText(),
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.5.sp
                )
            )
            if (subtitle != null) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = slateGaryOrWhite(),
                        fontWeight = FontWeight.Light
                    )
                )
            }
        }
        if (showViewAll) {
            Text(
                text = "DISCOVER",
                modifier = Modifier
                    .clickable { onViewAllClick() }
                    .padding(4.dp),
                color = ChampagneGold,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        }
    }
}

@Composable
fun SvaraTrackCard(
    title: String,
    artist: String,
    coverUrl: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .width(160.dp)
            .clickable { onClick() }
            .testTag("track_card_${title.replace(" ", "_")}"),
        colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, BorderGoldGray)
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            AsyncImage(
                model = coverUrl,
                contentDescription = "$title Cover Art",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(144.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(CharcoalDark)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = artist,
                color = SvaraSecondaryTextAccent(),
                fontWeight = FontWeight.Medium,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun SvaraStatCard(
    title: String,
    value: String,
    percentage: String,
    isPositive: Boolean = true,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, BorderGoldGray, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = CardSurfaceDark)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                color = SvaraSecondaryTextAccent(),
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = value,
                    style = MaterialTheme.typography.headlineMedium.copy(
                        color = RichGold,
                        fontWeight = FontWeight.Bold
                    )
                )
                Text(
                    text = if (isPositive) "+$percentage" else "-$percentage",
                    color = if (isPositive) SuccessGreen else ErrorRed,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

private fun SvaraSecondaryTextAccent(): Color = Color(0xFFC5B498)
private fun ActionGoldText(): Color = Color(0xFFE6C687)
private fun slateGaryOrWhite(): Color = Color(0xFF9E9E9E)
