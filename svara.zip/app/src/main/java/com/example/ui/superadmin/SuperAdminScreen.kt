package com.example.ui.superadmin

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BorderGoldGray
import com.example.ui.theme.CardSurfaceDark
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.RoyalGold

@Composable
fun SuperAdminScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(horizontal = 24.dp)
            .verticalScroll(rememberScrollState())
            .testTag("super_admin_screen_container")
    ) {
        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "SUPER MASTER ACCESS",
            color = RoyalGold,
            fontSize = 24.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.5.sp
        )

        Spacer(modifier = Modifier.height(20.dp))

        listOf(
            Triple("DATABASE CONNECTIONS", "Firestore Cluster: svara-instance-2026. Active listeners: 12,040.", Icons.Default.Dns),
            Triple("SECURITY AND ACCESS GATEWAYS", "Firebase auth policies: Normal. Global CDN edge: Safe and optimized.", Icons.Default.GppGood),
            Triple("LATENCY RENDERING LATENCY", "Cloudinary gateway sync times: 122ms. Dynamic stream encoding: Green.", Icons.Default.Speed)
        ).forEach { (title, desc, icon) ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
                border = BorderStroke(1.dp, BorderGoldGray)
            ) {
                Row(
                    modifier = Modifier.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = "Metrics icon",
                        tint = RoyalGold,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(text = title, color = ChampagneGold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = desc, color = Color.White, fontSize = 12.sp, lineHeight = 16.sp)
                    }
                }
            }
        }
    }
}
