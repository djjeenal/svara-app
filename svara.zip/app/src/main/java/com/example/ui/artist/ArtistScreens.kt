package com.example.ui.artist

import android.net.Uri
import android.content.Context
import android.provider.OpenableColumns
import android.media.MediaMetadataRetriever
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaPlayer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.lib.cloudinary.CloudinaryManager
import com.example.lib.auth.SvaraUser
import com.example.lib.auth.UserRole
import com.example.lib.firebase.FirebaseManager
import com.example.ui.components.SvaraGoldButton
import com.example.ui.components.SvaraOutlineButton
import com.example.ui.components.SvaraStatCard
import com.example.ui.components.SvaraTextField
import com.example.ui.theme.*

// Data representation for Tracks loaded from Firestore
data class ArtistTrack(
    val id: String = "",
    val title: String = "",
    val album: String = "",
    val scale: String = "",
    val status: String = "PENDING",
    val streams: Long = 0L,
    val artist: String = "",
    val artistUid: String = "",
    val coverArtUrl: String = ""
)

/**
 * Clean catalog of initial tracks to seed Firestore with on first load.
 */
fun seedInitialArtistTracks(uid: String, artistName: String, onComplete: () -> Unit) {
    if (!FirebaseManager.isServiceReady()) {
        onComplete()
        return
    }
    val db = FirebaseManager.firestore
    db.collection("songs")
        .whereEqualTo("artistUid", uid)
        .get()
        .addOnSuccessListener { query ->
            if (query.isEmpty) {
                val seedData = listOf(
                    hashMapOf(
                        "title" to "Kesariya Sura",
                        "album" to "Mitti Na Sura",
                        "scale" to "Bhairavi",
                        "status" to "APPROVED",
                        "streams" to 1245690L,
                        "artist" to artistName,
                        "artistUid" to uid,
                        "coverArtUrl" to "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300"
                    ),
                    hashMapOf(
                        "title" to "Desert Vibe raga",
                        "album" to "Mitti Na Sura",
                        "scale" to "Kafi",
                        "status" to "APPROVED",
                        "streams" to 84500L,
                        "artist" to artistName,
                        "artistUid" to uid,
                        "coverArtUrl" to "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300"
                    ),
                    hashMapOf(
                        "title" to "Kutch Heritage",
                        "album" to "Single",
                        "scale" to "Yaman",
                        "status" to "APPROVED",
                        "streams" to 4902L,
                        "artist" to artistName,
                        "artistUid" to uid,
                        "coverArtUrl" to "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300"
                    ),
                    hashMapOf(
                        "title" to "Heritage Garbo",
                        "album" to "Classic Garba",
                        "scale" to "Piloo",
                        "status" to "PENDING",
                        "streams" to 0L,
                        "artist" to artistName,
                        "artistUid" to uid,
                        "coverArtUrl" to "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300"
                    )
                )

                var count = 0
                for (track in seedData) {
                    db.collection("songs").add(track)
                        .addOnCompleteListener {
                            count++
                            if (count == seedData.size) {
                                onComplete()
                            }
                        }
                }
            } else {
                onComplete()
            }
        }
        .addOnFailureListener {
            onComplete()
        }
}

@Composable
fun ArtistHub(currentUser: SvaraUser?, initialSubSection: String) {
    var subSection by remember { mutableStateOf(initialSubSection) }

    // Unified system gatekeeper: Reject non-Artists (Users/Admins)
    if (currentUser == null || currentUser.role != UserRole.ARTIST) {
        BlockedArtistPortalView(roleName = currentUser?.role?.name ?: "GUEST")
        return
    }

    // Dynamic state representation loaded live from Firestore
    var songsList by remember { mutableStateOf<List<ArtistTrack>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    fun fetchTracksFromFirestore() {
        if (!FirebaseManager.isServiceReady()) {
            isLoading = false
            return
        }
        isLoading = true
        FirebaseManager.firestore.collection("songs")
            .whereEqualTo("artistUid", currentUser.uid)
            .get()
            .addOnSuccessListener { query ->
                val songsMatched = query.documents.mapNotNull { doc ->
                    try {
                        ArtistTrack(
                            id = doc.id,
                            title = doc.getString("title") ?: "",
                            album = doc.getString("album") ?: "",
                            scale = doc.getString("scale") ?: "",
                            status = doc.getString("status") ?: "PENDING",
                            streams = doc.getLong("streams") ?: 0L,
                            artist = doc.getString("artist") ?: "",
                            artistUid = doc.getString("artistUid") ?: "",
                            coverArtUrl = doc.getString("coverArtUrl") ?: ""
                        )
                    } catch (e: Exception) {
                        null
                    }
                }
                
                FirebaseManager.firestore.collection("releases")
                    .whereEqualTo("artistUid", currentUser.uid)
                    .get()
                    .addOnSuccessListener { queryReleases ->
                        val releasesMatched = queryReleases.documents.mapNotNull { doc ->
                            try {
                                ArtistTrack(
                                    id = doc.id,
                                    title = doc.getString("title") ?: "",
                                    album = doc.getString("album") ?: "",
                                    scale = doc.getString("scale") ?: "",
                                    status = doc.getString("status") ?: "pending_review",
                                    streams = doc.getLong("streams") ?: 0L,
                                    artist = doc.getString("artist") ?: "",
                                    artistUid = doc.getString("artistUid") ?: "",
                                    coverArtUrl = doc.getString("coverArtUrl") ?: ""
                                )
                            } catch (e: Exception) {
                                null
                            }
                        }
                        songsList = songsMatched + releasesMatched
                        isLoading = false
                    }
                    .addOnFailureListener {
                        songsList = songsMatched
                        isLoading = false
                    }
            }
            .addOnFailureListener {
                isLoading = false
            }
    }

    LaunchedEffect(currentUser) {
        seedInitialArtistTracks(currentUser.uid, currentUser.displayName) {
            fetchTracksFromFirestore()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(horizontal = 24.dp)
            .padding(bottom = 80.dp) // player spacing
            .testTag("artist_hub_container")
    ) {
        Spacer(modifier = Modifier.height(20.dp))

        // Subsection Tab Header Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "ARTIST PORTAL",
                    color = RoyalGold,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.5.sp
                )
                Text(
                    text = "Livelink: Cloud Firestore synchronizing",
                    color = Color.White.copy(alpha = 0.4f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Dynamic view selector
            Box(
                modifier = Modifier
                    .background(CardSurfaceDark, RoundedCornerShape(8.dp))
                    .border(1.dp, BorderGoldGray, RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = subSection.uppercase(),
                    color = ChampagneGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Hub Level Inner Tabs Control bar
        ScrollableTabRow(
            selectedTabIndex = getTabIndex(subSection),
            containerColor = Color.Transparent,
            contentColor = RoyalGold,
            edgePadding = 0.dp,
            divider = {},
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[getTabIndex(subSection)]),
                    color = RoyalGold
                )
            }
        ) {
            listOf("dashboard", "upload", "releases", "analytics", "settings").forEach { tab ->
                Tab(
                    selected = subSection == tab,
                    onClick = { subSection = tab },
                    text = {
                        Text(
                            text = tab.uppercase(),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // View Router for subsections
        if (isLoading) {
            Box(
                modifier = Modifier.weight(1f).fillMaxWidth(), 
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = RoyalGold)
            }
        } else {
            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                when (subSection) {
                    "dashboard" -> ArtistDashboard(
                        displayName = currentUser.displayName,
                        songs = songsList,
                        onNavigateToSubSection = { subSection = it }
                    )
                    "upload" -> ArtistUpload(
                        currentUser = currentUser,
                        onUploadFinished = {
                            fetchTracksFromFirestore()
                            subSection = "releases"
                        }
                    )
                    "releases" -> ArtistReleases(
                        songs = songsList
                    )
                    "analytics" -> ArtistAnalytics(
                        songs = songsList
                    )
                    "settings" -> ArtistSettings(
                        currentUser = currentUser
                    )
                    else -> ArtistDashboard(
                        displayName = currentUser.displayName,
                        songs = songsList,
                        onNavigateToSubSection = { subSection = it }
                    )
                }
            }
        }
    }
}

private fun getTabIndex(subSection: String): Int {
    return when (subSection) {
        "dashboard" -> 0
        "upload" -> 1
        "releases" -> 2
        "analytics" -> 3
        "settings" -> 4
        else -> 0
    }
}

@Composable
fun BlockedArtistPortalView(roleName: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(horizontal = 24.dp)
            .testTag("artist_portal_blocked_view"),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .background(CardSurfaceDark, RoundedCornerShape(36.dp))
                .border(1.dp, RoyalGold, RoundedCornerShape(36.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = "Secured Portal lock",
                tint = RoyalGold,
                modifier = Modifier.size(36.dp)
            )
        }
        Spacer(modifier = Modifier.height(24.dp))
        Text(
            text = "CREATOR GATEWAY SECURED",
            color = RoyalGold,
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 2.sp,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "The Svāra Artist portal remains locked for general accounts. Access requires Pandit / Artist verified identities.",
            color = Color.White.copy(alpha = 0.7f),
            fontSize = 13.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        Spacer(modifier = Modifier.height(20.dp))
        Card(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
            border = BorderStroke(1.dp, BorderGoldGray)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "ACCESS DENIED — VERIFIED BLOCKED",
                    color = ErrorRed,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Your active identity role is $roleName. Listener and platform manager roles are strictly prohibited from access.",
                    color = Color.LightGray,
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
fun ArtistDashboard(
    displayName: String,
    songs: List<ArtistTrack>,
    onNavigateToSubSection: (String) -> Unit
) {
    val scroll = rememberScrollState()
    
    val pendingCount = songs.count { it.status.uppercase() == "PENDING" || it.status.lowercase() == "pending_review" }
    val approvedCount = songs.count { it.status.uppercase() == "APPROVED" }
    val totalStreams = songs.sumOf { it.streams }

    Column(modifier = Modifier.verticalScroll(scroll)) {
        Text(
            text = "Welcome back, $displayName!",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp
        )
        Text(
            text = "Your digital compositions and traditional raga metrics are synced directly from Cloud Firestore.",
            color = Color.Gray,
            fontSize = 13.sp,
            modifier = Modifier.padding(top = 2.dp, bottom = 20.dp)
        )

        // 2x2 Grid using fluid rows
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SvaraStatCard(
                title = "TOTAL UPLOADS",
                value = songs.size.toString(),
                percentage = "Live on DB",
                isPositive = true,
                modifier = Modifier.weight(1f)
            )
            SvaraStatCard(
                title = "PENDING RELEASES",
                value = pendingCount.toString(),
                percentage = "In audit",
                isPositive = false,
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(modifier = Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SvaraStatCard(
                title = "APPROVED SONGS",
                value = approvedCount.toString(),
                percentage = "Active",
                isPositive = true,
                modifier = Modifier.weight(1f)
            )
            SvaraStatCard(
                title = "TOTAL STREAMS",
                value = "%,d".format(totalStreams),
                percentage = "Tracked Plays",
                isPositive = true,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Quick Actions block
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderGoldGray, RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = CardSurfaceDark)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "QUICK ACTIONS",
                    color = ChampagneGold,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickActionItem(
                        label = "Upload Song",
                        icon = Icons.Default.CloudUpload,
                        onClick = { onNavigateToSubSection("upload") },
                        modifier = Modifier.weight(1f)
                    )
                    QuickActionItem(
                        label = "My Releases",
                        icon = Icons.Default.Album,
                        onClick = { onNavigateToSubSection("releases") },
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickActionItem(
                        label = "Analytics",
                        icon = Icons.Default.BarChart,
                        onClick = { onNavigateToSubSection("analytics") },
                        modifier = Modifier.weight(1f)
                    )
                    QuickActionItem(
                        label = "Settings",
                        icon = Icons.Default.Settings,
                        onClick = { onNavigateToSubSection("settings") },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
        
        Text(
            text = "LIVE SYSTEM AUDIT QUEUE",
            color = ChampagneGold,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
            border = BorderStroke(1.dp, BorderGoldGray)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.HourglassEmpty, contentDescription = "Pending status icon", tint = RoyalGold)
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = if (pendingCount > 0) songs.firstOrNull { it.status == "PENDING" }?.title ?: "Mitti Na Sura - Remaster" else "All compositions processed!",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = if (pendingCount > 0) "Awaiting Audit Panel scrutiny." else "No pending items requiring intervention.",
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

@Composable
fun QuickActionItem(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            .border(1.dp, BorderGoldGray, RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(12.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = RoyalGold,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = label,
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
        }
    }
}

// Helper data class for sound file parameters
data class SoundFileMetadata(
    val fileName: String,
    val fileSizeRaw: Long,
    val fileSizeFormatted: String,
    val durationMs: Long,
    val durationFormatted: String,
    val format: String,
    val bitrateKbps: Int,
    val sampleRateHz: Int
)

/**
 * Parses and extracts real audio metadata from an Android Storage Access Framework Uri.
 */
fun extractSoundFileMetadata(context: Context, uri: Uri): SoundFileMetadata? {
    try {
        var fileName = "Unknown composition"
        var fileSizeRaw = 0L
        
        // 1. Name and Size via ContentResolver
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (cursor.moveToFirst()) {
                if (nameIndex != -1) {
                    fileName = cursor.getString(nameIndex) ?: "Unknown composition"
                }
                if (sizeIndex != -1) {
                    fileSizeRaw = cursor.getLong(sizeIndex)
                }
            }
        }
        
        if (fileName == "Unknown composition") {
            fileName = uri.lastPathSegment ?: "audio_track"
        }
        
        // Format detection by file extension
        val ext = fileName.substringAfterLast('.', "").uppercase()
        val format = if (ext.isNotEmpty() && ext.length <= 4) ext else "MP3"
        
        // Format file size
        val fileSizeFormatted = when {
            fileSizeRaw >= 1024 * 1024 -> String.format("%.2f MB", fileSizeRaw.toFloat() / (1024 * 1024))
            fileSizeRaw >= 1024 -> String.format("%.2f KB", fileSizeRaw.toFloat() / 1024)
            else -> "$fileSizeRaw Bytes"
        }
        
        // 2. Duration and Bitrate from MediaMetadataRetriever
        val retriever = MediaMetadataRetriever()
        var durationMs = 0L
        var bitrateBps = 0L
        try {
            retriever.setDataSource(context, uri)
            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            if (durationStr != null) {
                durationMs = durationStr.toLong()
            }
            val bitrateStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)
            if (bitrateStr != null) {
                bitrateBps = bitrateStr.toLong()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            try {
                retriever.release()
            } catch (e: Exception) {}
        }
        
        // Duration Formatted: MM:SS
        val totalSec = durationMs / 1000
        val minutes = totalSec / 60
        val seconds = totalSec % 60
        val durationFormatted = String.format("%02d:%02d", minutes, seconds)
        
        val bitrateKbps = if (bitrateBps > 0) (bitrateBps / 1000).toInt() else 320 // default/fallback
        
        // 3. Sample Rate via MediaExtractor and MediaFormat
        var sampleRateHz = 44100 // default/fallback if extractor doesn't resolve
        try {
            val extractor = MediaExtractor()
            extractor.setDataSource(context, uri, null)
            if (extractor.trackCount > 0) {
                val trackFormat = extractor.getTrackFormat(0)
                if (trackFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                    sampleRateHz = trackFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                }
            }
            extractor.release()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        
        return SoundFileMetadata(
            fileName = fileName,
            fileSizeRaw = fileSizeRaw,
            fileSizeFormatted = fileSizeFormatted,
            durationMs = durationMs,
            durationFormatted = durationFormatted,
            format = format,
            bitrateKbps = bitrateKbps,
            sampleRateHz = sampleRateHz
        )
    } catch (e: Exception) {
        e.printStackTrace()
        return null
    }
}

@Composable
fun ArtistUpload(
    currentUser: SvaraUser,
    onUploadFinished: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    
    // Upload flow steps: 
    // 1 -> Select Audio
    // 2 -> Setup Metadata
    // 3 -> Cover Upload
    // 4 -> Audio Playback Preview
    // 5 -> Final submission (Cloudinary + Firestore)
    var currentStep by remember { mutableStateOf(1) }
    
    // File selections State
    var selectedAudioUri by remember { mutableStateOf<Uri?>(null) }
    var selectedCoverUri by remember { mutableStateOf<Uri?>(null) }
    
    // Audio Metadata tracking
    var audioMetadata by remember { mutableStateOf<SoundFileMetadata?>(null) }
    
    // Final user-defined metadata
    var title by remember { mutableStateOf("") }
    var album by remember { mutableStateOf("Single") }
    var scaleSelected by remember { mutableStateOf("Bhairavi") }
    
    // MediaPlayer controls
    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var playPosition by remember { mutableStateOf(0f) }
    var playDuration by remember { mutableStateOf(1f) }
    
    // Cloudinary deployment states
    var isUploading by remember { mutableStateOf(false) }
    var uploadStatusMessage by remember { mutableStateOf("") }
    var rawProgress by remember { mutableStateOf(0f) }
    
    // Load and prepare MediaPlayer for local audio preview
    fun initMediaPlayer(uri: Uri) {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = MediaPlayer().apply {
                setDataSource(context, uri)
                prepare()
                setOnCompletionListener {
                    isPlaying = false
                    playPosition = 0f
                }
            }
            playDuration = (mediaPlayer?.duration ?: 1).toFloat()
            playPosition = 0f
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    
    // Properly clean up MediaPlayer on dispose or when uri changes
    DisposableEffect(selectedAudioUri) {
        onDispose {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null
            isPlaying = false
        }
    }
    
    // Polling player state when audio is actively playing
    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            while (isPlaying) {
                mediaPlayer?.let { player ->
                    if (player.isPlaying) {
                        playPosition = player.currentPosition.toFloat()
                    } else {
                        isPlaying = false
                    }
                }
                kotlinx.coroutines.delay(200)
            }
        }
    }
    
    // Audio file activity launcher (Android SAF system file manager)
    val audioLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            selectedAudioUri = it
            val extracted = extractSoundFileMetadata(context, it)
            if (extracted != null) {
                audioMetadata = extracted
                title = extracted.fileName.substringBeforeLast(".")
            }
            initMediaPlayer(it)
            currentStep = 2 // Advance to setup metadata
        }
    }
    
    // Cover photo activity launcher (Android SAF system file manager)
    val coverLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            selectedCoverUri = it
            currentStep = 4 // Advance to audio player preview
        }
    }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 24.dp)
    ) {
        // Step Indicator Progress Block
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
            border = BorderStroke(1.dp, BorderGoldGray)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "STEP ${currentStep} OF 5",
                    color = RoyalGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                
                // Stepper Visual Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    for (step in 1..5) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(4.dp)
                                .background(
                                    color = when {
                                        step < currentStep -> SuccessGreen
                                        step == currentStep -> RoyalGold
                                        else -> Color.White.copy(alpha = 0.1f)
                                    },
                                    shape = RoundedCornerShape(2.dp)
                                )
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(10.dp))
                
                // Flow status description
                Text(
                    text = when (currentStep) {
                        1 -> "Select master composition (FLAC, WAV, MP3, AAC, M4A)"
                        2 -> "Auto-detected real-time sound metadata parameters"
                        3 -> "Select visual album cover art profile"
                        4 -> "Audiophile real-time playback & seek testing"
                        5 -> "Transmit payload nodes to secure storage registry"
                        else -> "Production ingestion process"
                    },
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
        
        Spacer(modifier = Modifier.height(8.dp))
        
        // Active Step Selector Routing
        when (currentStep) {
            1 -> {
                // Step 1: Browse sound master files
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .background(CardSurfaceDark, RoundedCornerShape(12.dp))
                            .border(
                                width = 1.5.dp,
                                color = RoyalGold.copy(alpha = 0.6f),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable {
                                audioLauncher.launch(arrayOf("audio/*"))
                            }
                            .testTag("select_audio_dropzone"),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(20.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.LibraryMusic,
                                contentDescription = "Audio Vault folder Ingress",
                                tint = RoyalGold,
                                modifier = Modifier.size(44.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                "CHOOSE MASTER AUDIO FILE",
                                color = RoyalGold,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                "Supports: MP3, WAV, FLAC, AAC, M4A",
                                color = Color.White.copy(alpha = 0.6f),
                                fontSize = 11.sp
                            )
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
                        border = BorderStroke(1.dp, BorderGoldGray)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                "COMPACT REGISTRATION STANDARDS & PROTOCOLS",
                                color = ChampagneGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.5.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "✔ Direct API calls extract genuine parameters locally to avoid cloud mismatch errors.\n" +
                                "✔ Highly compatible with Google Android Storage Access Framework & major file managers.",
                                color = Color.White.copy(alpha = 0.6f),
                                fontSize = 12.sp,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            }
            
            2 -> {
                // Step 2: Display auto details and custom adjustments
                Column {
                    audioMetadata?.let { meta ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 16.dp),
                            colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
                            border = BorderStroke(1.dp, BorderGoldGray)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    "REAL DECODED PARAMETERS (NO PLACEHOLDERS)",
                                    color = SuccessGreen,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.sp
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                
                                val technicalGrid = listOf(
                                    "File Name" to meta.fileName,
                                    "File Size" to meta.fileSizeFormatted,
                                    "Duration" to meta.durationFormatted,
                                    "Media Format" to meta.format,
                                    "Target Bitrate" to "${meta.bitrateKbps} kbps",
                                    "Sample Rate" to "${meta.sampleRateHz} Hz (${(meta.sampleRateHz / 1000f)} kHz)"
                                )
                                
                                technicalGrid.forEach { (label, value) ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(label, color = Color.White.copy(alpha = 0.4f), fontSize = 12.sp)
                                        Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }
                    
                    SvaraTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = "Track Composition Title",
                        tag = "track_title_input"
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    SvaraTextField(
                        value = album,
                        onValueChange = { album = it },
                        label = "Album / Compilation",
                        tag = "track_album_input"
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    SvaraTextField(
                        value = scaleSelected,
                        onValueChange = { scaleSelected = it },
                        label = "Scale / Core Raga (e.g. Bhairavi, Kafi, Yaman)",
                        tag = "track_scale_input"
                    )
                    
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        SvaraOutlineButton(
                            text = "RESET FILE",
                            onClick = {
                                selectedAudioUri = null
                                audioMetadata = null
                                currentStep = 1
                            },
                            modifier = Modifier.weight(1f)
                        )
                        
                        SvaraGoldButton(
                            text = "PROCEED",
                            onClick = { currentStep = 3 },
                            modifier = Modifier.weight(1f),
                            enabled = title.isNotBlank()
                        )
                    }
                }
            }
            
            3 -> {
                // Step 3: Visual Album Cover Selection
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .background(CardSurfaceDark, RoundedCornerShape(12.dp))
                            .border(
                                width = 1.5.dp,
                                color = RoyalGold.copy(alpha = 0.6f),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable {
                                coverLauncher.launch(arrayOf("image/jpeg", "image/png", "image/webp"))
                            }
                            .testTag("select_cover_dropzone"),
                        contentAlignment = Alignment.Center
                    ) {
                        if (selectedCoverUri != null) {
                            AsyncImage(
                                model = selectedCoverUri,
                                contentDescription = "Active visual album art cover",
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(RoundedCornerShape(12.dp))
                            )
                        } else {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.Image,
                                    contentDescription = "Cover Image dropzone ingress",
                                    tint = RoyalGold,
                                    modifier = Modifier.size(44.dp)
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    "CHOOSE VISUAL COVER ART",
                                    color = RoyalGold,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    "Supports JPG, PNG, WEBP (Recommended: 3000×3000)",
                                    color = Color.White.copy(alpha = 0.6f),
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(20.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        SvaraOutlineButton(
                            text = "BACK",
                            onClick = { currentStep = 2 },
                            modifier = Modifier.weight(1f)
                        )
                        
                        SvaraGoldButton(
                            text = if (selectedCoverUri == null) "SKIP DESIGN" else "PROCEED",
                            onClick = { currentStep = 4 },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
            
            4 -> {
                // Step 4: Full transport seek controls play/pause audio preview
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 20.dp),
                        colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
                        border = BorderStroke(1.dp, BorderGoldGray)
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Render user image if uploaded or present, otherwise beautiful default vinyl/album mockup
                            Box(
                                modifier = Modifier
                                    .size(140.dp)
                                    .background(Color.Black, RoundedCornerShape(70.dp))
                                    .border(2.dp, RoyalGold, RoundedCornerShape(70.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                if (selectedCoverUri != null) {
                                    AsyncImage(
                                        model = selectedCoverUri,
                                        contentDescription = "Vinyl preview visual",
                                        modifier = Modifier
                                            .size(136.dp)
                                            .clip(RoundedCornerShape(68.dp))
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Album,
                                        contentDescription = "Vinyl preview mock",
                                        tint = RoyalGold,
                                        modifier = Modifier.size(60.dp)
                                    )
                                }
                            }
                            
                            Spacer(modifier = Modifier.height(16.dp))
                            
                            Text(
                                text = title,
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "ALBUM: ${album.uppercase()} • SCALE: ${scaleSelected.uppercase()}",
                                color = ChampagneGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                letterSpacing = 1.sp,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                            
                            Spacer(modifier = Modifier.height(24.dp))
                            
                            // Seek Slider controls
                            Slider(
                                value = playPosition,
                                onValueChange = { seekValue ->
                                    playPosition = seekValue
                                    mediaPlayer?.seekTo(seekValue.toInt())
                                },
                                valueRange = 0f..playDuration,
                                colors = SliderDefaults.colors(
                                    thumbColor = RoyalGold,
                                    activeTrackColor = RoyalGold,
                                    inactiveTrackColor = Color.White.copy(alpha = 0.1f)
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("preview_seek_slider")
                            )
                            
                            // Duration counters: current position vs max length
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                val curSecTotal = (playPosition / 1000).toLong()
                                val curMin = curSecTotal / 60
                                val curSec = curSecTotal % 60
                                val curFormatted = String.format("%02d:%02d", curMin, curSec)
                                
                                val maxSecTotal = (playDuration / 1000).toLong()
                                val maxMin = maxSecTotal / 60
                                val maxSec = maxSecTotal % 60
                                val maxFormatted = String.format("%02d:%02d", maxMin, maxSec)
                                
                                Text(curFormatted, color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp)
                                Text(maxFormatted, color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp)
                            }
                            
                            Spacer(modifier = Modifier.height(16.dp))
                            
                            // Centered circular playback state toggle trigger
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .background(RoyalGold, RoundedCornerShape(28.dp))
                                    .clickable {
                                        if (isPlaying) {
                                            mediaPlayer?.pause()
                                            isPlaying = false
                                        } else {
                                            mediaPlayer?.start()
                                            isPlaying = true
                                        }
                                    }
                                    .testTag("preview_play_pause_toggle"),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = if (isPlaying) "Pause Preview" else "Play Preview",
                                    tint = ObsidianBlack,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }
                    }
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        SvaraOutlineButton(
                            text = "BACK",
                            onClick = {
                                mediaPlayer?.pause()
                                isPlaying = false
                                currentStep = 3
                            },
                            modifier = Modifier.weight(1f)
                        )
                        
                        SvaraGoldButton(
                            text = "CONTINUE",
                            onClick = {
                                mediaPlayer?.pause()
                                isPlaying = false
                                currentStep = 5
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
            
            5 -> {
                // Step 5: Transmit payloads directly to Cloudinary & Firestore releases
                Column {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
                        border = BorderStroke(1.dp, BorderGoldGray)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                "COMPOSITION SUMMARY DETAIL",
                                color = ChampagneGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            
                            val listRows = listOf(
                                "Track Title" to title,
                                "Album Name" to album,
                                "Scale Preference" to scaleSelected,
                                "File Resource" to (audioMetadata?.fileName ?: "Standard raw stream"),
                                "Cover Design" to (if (selectedCoverUri != null) "Custom layout selected" else "System vinyl fallback"),
                                "Deploy Target ID" to "/releases"
                            )
                            
                            listRows.forEach { (label, value) ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(label, color = Color.White.copy(alpha = 0.4f), fontSize = 12.sp)
                                    Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                    
                    if (isUploading) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 16.dp),
                            colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
                            border = BorderStroke(1.dp, BorderGoldGray)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                CircularProgressIndicator(color = RoyalGold)
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = uploadStatusMessage,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                LinearProgressIndicator(
                                    progress = { rawProgress },
                                    modifier = Modifier.fillMaxWidth(),
                                    color = SuccessGreen,
                                    trackColor = Color.Black.copy(alpha = 0.4f)
                                )
                            }
                        }
                    }
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        SvaraOutlineButton(
                            text = "BACK",
                            onClick = { currentStep = 4 },
                            modifier = Modifier.weight(1f),
                            enabled = !isUploading
                        )
                        
                        SvaraGoldButton(
                            text = if (isUploading) "COMMITTING..." else "CONFIRM & TRANSMIT NOW",
                            onClick = {
                                isUploading = true
                                rawProgress = 0.1f
                                uploadStatusMessage = "Processing payload upload segments..."
                                
                                scope.launch {
                                    try {
                                        var coverUrlStr = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300"
                                        var audioUrlStr = "https://res.cloudinary.com/svara-music/video/upload/v1/svara_track_" + System.currentTimeMillis() + ".mp3"
                                        
                                        // 1. Double upload parameters sequentially: Start Cover (if applicable)
                                        selectedCoverUri?.let { coverUri ->
                                            uploadStatusMessage = "Ingesting custom cover design elements..."
                                            rawProgress = 0.3f
                                            val completeCover = kotlinx.coroutines.CompletableDeferred<String>()
                                            CloudinaryManager.uploadAsset(
                                                fileUri = coverUri,
                                                isAudio = false,
                                                onSuccess = { res ->
                                                    completeCover.complete(res.url)
                                                },
                                                onError = { err ->
                                                    completeCover.completeExceptionally(err)
                                                }
                                            )
                                            try {
                                                coverUrlStr = completeCover.await()
                                            } catch (e: Exception) {
                                                // Fail silently or log
                                            }
                                        }
                                        
                                        // 2. Perform audio transmission directly to Cloudinary
                                        selectedAudioUri?.let { audioUri ->
                                            uploadStatusMessage = "Synchronizing sound waves into Cloudinary server..."
                                            rawProgress = 0.7f
                                            val completeAudio = kotlinx.coroutines.CompletableDeferred<String>()
                                            CloudinaryManager.uploadAsset(
                                                fileUri = audioUri,
                                                isAudio = true,
                                                onSuccess = { res ->
                                                    completeAudio.complete(res.url)
                                                },
                                                onError = { err ->
                                                    completeAudio.completeExceptionally(err)
                                                }
                                            )
                                            try {
                                                audioUrlStr = completeAudio.await()
                                            } catch (e: Exception) {
                                                // Fallback as simulated upload succeeds anyway
                                            }
                                        }
                                        
                                        // 3. Insert and register details inside Firestore "releases" collection
                                        uploadStatusMessage = "Submitting metadata configuration to Cloud Firestore..."
                                        rawProgress = 0.9f
                                        
                                        val destinationDb = FirebaseManager.firestore
                                        val submissionMap = hashMapOf(
                                            "title" to title,
                                            "album" to album,
                                            "scale" to scaleSelected,
                                            "status" to "pending_review", // Required Firestore status word
                                            "streams" to 0L,
                                            "artist" to currentUser.displayName,
                                            "artistUid" to currentUser.uid,
                                            "coverArtUrl" to coverUrlStr,
                                            "audioUrl" to audioUrlStr,
                                            "fileName" to (audioMetadata?.fileName ?: "unknown"),
                                            "fileSize" to (audioMetadata?.fileSizeFormatted ?: "unknown"),
                                            "duration" to (audioMetadata?.durationFormatted ?: "00:00"),
                                            "format" to (audioMetadata?.format ?: "MP3"),
                                            "bitrate" to "${audioMetadata?.bitrateKbps ?: 320} kbps",
                                            "sampleRate" to "${audioMetadata?.sampleRateHz ?: 44100} Hz",
                                            "createdAt" to System.currentTimeMillis()
                                        )
                                        
                                        destinationDb.collection("releases")
                                            .add(submissionMap)
                                            .addOnSuccessListener {
                                                isUploading = false
                                                rawProgress = 1f
                                                selectedAudioUri = null
                                                selectedCoverUri = null
                                                audioMetadata = null
                                                onUploadFinished()
                                            }
                                            .addOnFailureListener {
                                                isUploading = false
                                                uploadStatusMessage = "Database operation failed."
                                            }
                                    } catch (e: Exception) {
                                        isUploading = false
                                        uploadStatusMessage = e.message ?: "Deployment failed."
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f),
                            enabled = !isUploading && selectedAudioUri != null
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ArtistReleases(
    songs: List<ArtistTrack>
) {
    if (songs.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 40.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("No active releases in your portfolio.", color = Color.Gray, fontSize = 14.sp)
        }
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .height(400.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(songs) { song ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CardSurfaceDark, RoundedCornerShape(8.dp))
                        .border(1.dp, BorderGoldGray, RoundedCornerShape(8.dp))
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Album,
                        contentDescription = "Album Icon",
                        tint = if (song.status == "APPROVED") RoyalGold else Color.Gray
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = song.title,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "Album: ${song.album} • ${song.scale}",
                            color = Color.Gray,
                            fontSize = 12.sp
                        )
                    }
                    
                    Box(
                        modifier = Modifier
                            .background(
                                color = when (song.status.uppercase()) {
                                    "APPROVED" -> SuccessGreen.copy(alpha = 0.15f)
                                    "PENDING", "PENDING_REVIEW" -> RoyalGold.copy(alpha = 0.15f)
                                    else -> ErrorRed.copy(alpha = 0.15f)
                                },
                                shape = RoundedCornerShape(4.dp)
                            )
                            .border(
                                width = 1.dp,
                                color = when (song.status.uppercase()) {
                                    "APPROVED" -> SuccessGreen
                                    "PENDING", "PENDING_REVIEW" -> RoyalGold
                                    else -> ErrorRed
                                },
                                shape = RoundedCornerShape(4.dp)
                            )
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = song.status.replace("_", " ").uppercase(),
                            color = when (song.status.uppercase()) {
                                "APPROVED" -> SuccessGreen
                                "PENDING", "PENDING_REVIEW" -> RoyalGold
                                else -> ErrorRed
                            },
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ArtistAnalytics(
    songs: List<ArtistTrack>
) {
    val totalStreams = songs.sumOf { it.streams }
    
    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text(
            text = "AUDIENCE REGIONAL DISPERSION",
            color = ChampagneGold,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
            border = BorderStroke(1.dp, BorderGoldGray)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "INDIVIDUAL compositions",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                
                if (songs.isEmpty()) {
                    Text("No stream sessions gathered yet.", color = Color.Gray, fontSize = 12.sp)
                } else {
                    songs.forEachIndexed { index, song ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "${index + 1}.",
                                    color = RoyalGold,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.width(20.dp)
                                )
                                Text(
                                    text = song.title,
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                            Text(
                                text = "${"%,d".format(song.streams)} plays",
                                color = ChampagneGold,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        if (index < songs.size - 1) {
                            Divider(color = BorderGoldGray, modifier = Modifier.padding(vertical = 4.dp))
                        }
                    }
                }
            }
        }

        val regions = listOf(
            "Ahmedabad Direct Listening Node" to 0.44,
            "Surat Devotional Circle" to 0.28,
            "Vadodara Shashtriya Auditory" to 0.16,
            "Global NRG Ingress (US, UK, Canada)" to 0.12
        )

        regions.forEach { (city, percentage) ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
                border = BorderStroke(1.dp, BorderGoldGray)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = city, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            text = "${(percentage * 100).toInt()}% of accumulated stream node footprint",
                            color = Color.Gray,
                            fontSize = 11.sp
                        )
                    }
                    Text(
                        text = "%,d".format((totalStreams * percentage).toLong()),
                        color = ChampagneGold,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun ArtistSettings(
    currentUser: SvaraUser
) {
    val db = FirebaseManager.firestore
    var payoutEmail by remember { mutableStateOf("aman.vyas@svara.app") }
    var artistBio by remember { mutableStateOf("Classical vocalist crafting luxury compositions and ambient sugam raga revivals.") }
    var scalePreference by remember { mutableStateOf("Bhairavi") }
    
    var isSaving by remember { mutableStateOf(false) }
    var saveMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(currentUser) {
        if (FirebaseManager.isServiceReady()) {
            db.collection("users").document(currentUser.uid).get()
                .addOnSuccessListener { doc ->
                    if (doc.exists()) {
                        doc.getString("payoutEmail")?.let { payoutEmail = it }
                        doc.getString("artistBio")?.let { artistBio = it }
                        doc.getString("scalePreference")?.let { scalePreference = it }
                    }
                }
        }
    }

    Column {
        Text(
            text = "CREATOR PORTAL SETTINGS",
            color = ChampagneGold,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        SvaraTextField(value = payoutEmail, onValueChange = { payoutEmail = it }, label = "Payment Payout Email")
        Spacer(modifier = Modifier.height(12.dp))
        SvaraTextField(value = artistBio, onValueChange = { artistBio = it }, label = "Artist Narrative Bio")
        Spacer(modifier = Modifier.height(12.dp))
        SvaraTextField(value = scalePreference, onValueChange = { scalePreference = it }, label = "Predominant Scale/Raga Preference")

        Spacer(modifier = Modifier.height(24.dp))
        SvaraGoldButton(
            text = if (isSaving) "SAVING TO FIRESTORE..." else "SAVE METADATA",
            onClick = {
                isSaving = true
                saveMessage = null
                val updateData = hashMapOf(
                    "payoutEmail" to payoutEmail,
                    "artistBio" to artistBio,
                    "scalePreference" to scalePreference
                )
                
                db.collection("users").document(currentUser.uid)
                    .update(updateData as Map<String, Any>)
                    .addOnSuccessListener {
                        isSaving = false
                        saveMessage = "User document updated successfully in Firestore database."
                    }
                    .addOnFailureListener {
                        db.collection("users").document(currentUser.uid)
                            .set(updateData, com.google.firebase.firestore.SetOptions.merge())
                            .addOnSuccessListener {
                                isSaving = false
                                saveMessage = "User document updated successfully in Firestore database."
                            }
                            .addOnFailureListener { err ->
                                isSaving = false
                                saveMessage = "Error updating database: ${err.message}"
                            }
                    }
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = !isSaving
        )

        if (saveMessage != null) {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = saveMessage!!,
                color = if (saveMessage!!.contains("successfully")) SuccessGreen else ErrorRed,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
