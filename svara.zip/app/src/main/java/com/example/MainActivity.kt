package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.ui.graphics.Brush
import com.example.ui.components.SvaraGoldGradient
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.lib.auth.AuthManager
import com.example.lib.auth.UserRole
import com.example.lib.audio.AudioPlayerManager
import com.example.lib.audio.Track
import com.example.ui.admin.AdminHub
import com.example.ui.artist.ArtistHub
import com.example.ui.auth.AuthScreen
import com.example.ui.home.HomeScreen
import com.example.ui.library.LibraryScreen
import com.example.ui.navigation.SvaraScreen
import com.example.ui.player.PlayerScreen
import com.example.ui.search.SearchScreen
import com.example.ui.superadmin.SuperAdminScreen
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {
    private val authManager = AuthManager()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SvaraTheme {
                SvaraPlatformApp(authManager)
            }
        }
    }
}

@Composable
fun SvaraPlatformApp(authManager: AuthManager) {
    val currentUser by authManager.currentUser.collectAsState()
    var currentScreen by remember { mutableStateOf(SvaraScreen.HOME) }
    var previousScreenBeforePlayer by remember { mutableStateOf(SvaraScreen.HOME) }

    // Role switcher dropdown state
    var showRoleSwitcher by remember { mutableStateOf(false) }

    // Floating Player State
    val nowPlayingTrack by AudioPlayerManager.currentTrack.collectAsState()
    val isPlaying by AudioPlayerManager.isPlaying.collectAsState()

    // Determine viewport details for responsive layouts
    val configuration = LocalConfiguration.current
    val screenWidthDp = configuration.screenWidthDp
    val isExpandedLayout = screenWidthDp > 600

    // Auto-routing based on authenticated User Role (Session Persistence & Custom Redirect Rules)
    LaunchedEffect(currentUser) {
        AudioPlayerManager.onUserChanged(currentUser?.uid)
        currentUser?.let { user ->
            currentScreen = when (user.role) {
                UserRole.USER -> SvaraScreen.HOME
                UserRole.ARTIST -> SvaraScreen.ARTIST_DASHBOARD
                UserRole.ADMIN -> SvaraScreen.ADMIN_DASHBOARD
                UserRole.SUPER_ADMIN -> SvaraScreen.SUPER_ADMIN
            }
        }
    }

    if (currentUser == null) {
        AuthScreen(
            authManager = authManager,
            onLoginSuccess = { role ->
                val assignedRole = try {
                    UserRole.valueOf(role)
                } catch (e: Exception) {
                    UserRole.USER
                }
                authManager.switchRoleForTesting(assignedRole)
                currentScreen = when (assignedRole) {
                    UserRole.USER -> SvaraScreen.HOME
                    UserRole.ARTIST -> SvaraScreen.ARTIST_DASHBOARD
                    UserRole.ADMIN -> SvaraScreen.ADMIN_DASHBOARD
                    UserRole.SUPER_ADMIN -> SvaraScreen.SUPER_ADMIN
                }
            }
        )
    } else {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = ObsidianBlack,
            bottomBar = {
                // Adaptive layout: Only display Bottom navigation on normal handheld devices
                if (!isExpandedLayout && currentScreen != SvaraScreen.PLAYER) {
                    SvaraBottomBar(
                        role = currentUser?.role ?: UserRole.USER,
                        currentScreen = currentScreen,
                        onScreenSelect = {
                            currentScreen = it
                        }
                    )
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(
                        top = innerPadding.calculateTopPadding(),
                        bottom = if (isExpandedLayout) innerPadding.calculateBottomPadding() else 0.dp
                    )
            ) {
                // Adaptive Layout: Navigation Rail on Expanded (Tablet/Foldable) Form Factors
                if (isExpandedLayout && currentScreen != SvaraScreen.PLAYER) {
                    SvaraNavigationRail(
                        role = currentUser?.role ?: UserRole.USER,
                        currentScreen = currentScreen,
                        onScreenSelect = {
                            currentScreen = it
                        }
                    )
                }

                // Primary Platform Content
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                ) {
                    when (currentScreen) {
                        SvaraScreen.HOME -> HomeScreen(
                            onTrackSelect = { AudioPlayerManager.playTrack(it) },
                            onNavigateToPlayer = {
                                previousScreenBeforePlayer = currentScreen
                                currentScreen = SvaraScreen.PLAYER
                            }
                        )
                        SvaraScreen.SEARCH -> SearchScreen(
                            onTrackSelect = { AudioPlayerManager.playTrack(it) }
                        )
                        SvaraScreen.LIBRARY -> LibraryScreen()
                        SvaraScreen.PLAYER -> PlayerScreen(onBackClick = { currentScreen = previousScreenBeforePlayer })

                        // Artist sub-modules routed through unified portal
                        SvaraScreen.ARTIST_DASHBOARD -> ArtistHub(currentUser, "dashboard")
                        SvaraScreen.ARTIST_UPLOAD -> ArtistHub(currentUser, "upload")
                        SvaraScreen.ARTIST_RELEASES -> ArtistHub(currentUser, "releases")
                        SvaraScreen.ARTIST_ANALYTICS -> ArtistHub(currentUser, "analytics")
                        SvaraScreen.ARTIST_SETTINGS -> ArtistHub(currentUser, "settings")

                        // Admin sub-modules routed through unified panel
                        SvaraScreen.ADMIN_DASHBOARD -> AdminHub(currentUser?.role, "dashboard")
                        SvaraScreen.ADMIN_APPROVALS -> AdminHub(currentUser?.role, "approvals")
                        SvaraScreen.ADMIN_FEATURED -> AdminHub(currentUser?.role, "featured")
                        SvaraScreen.ADMIN_USERS -> AdminHub(currentUser?.role, "users")

                        SvaraScreen.SUPER_ADMIN -> SuperAdminScreen()
                        else -> HomeScreen(
                            onTrackSelect = { AudioPlayerManager.playTrack(it) },
                            onNavigateToPlayer = { currentScreen = SvaraScreen.PLAYER }
                        )
                    }

                    // Floating Mini-Player bar (appears if music starts but not in full Player details)
                    if (nowPlayingTrack != null && currentScreen != SvaraScreen.PLAYER) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(horizontal = 16.dp, vertical = if (isExpandedLayout) 16.dp else 100.dp) // adjust for bottom bars
                        ) {
                            SvaraMiniPlayer(
                                track = nowPlayingTrack!!,
                                isPlaying = isPlaying,
                                onToggle = { AudioPlayerManager.togglePlayback() },
                                onExpand = {
                                    previousScreenBeforePlayer = currentScreen
                                    currentScreen = SvaraScreen.PLAYER
                                }
                            )
                        }
                    }

                    // Luxury Flowing Header Controller (Floating overlay)
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(16.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.End) {
                            // Subtle role controller badge clicked to reveal dropdown
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(Color.Black.copy(alpha = 0.85f))
                                    .border(1.dp, SvaraGoldGradient, RoundedCornerShape(20.dp))
                                    .clickable { showRoleSwitcher = !showRoleSwitcher }
                                    .padding(horizontal = 14.dp, vertical = 6.dp)
                                    .testTag("svara_role_pill")
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(RichGold)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = (currentUser?.role?.name ?: "USER"),
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Black,
                                        letterSpacing = 0.5.sp
                                    )
                                }
                            }

                            // Selection Popover for role swapping
                            if (showRoleSwitcher) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Card(
                                    modifier = Modifier
                                        .width(180.dp)
                                        .border(1.dp, BorderGoldGray, RoundedCornerShape(12.dp)),
                                    colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Column(modifier = Modifier.padding(8.dp)) {
                                        Text(
                                            text = "SWAP ENVIRONMENT",
                                            color = Color.Gray,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(8.dp)
                                        )

                                        UserRole.values().forEach { role ->
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .clickable {
                                                        authManager.switchRoleForTesting(role)
                                                        showRoleSwitcher = false
                                                        currentScreen = when (role) {
                                                            UserRole.USER -> SvaraScreen.HOME
                                                            UserRole.ARTIST -> SvaraScreen.ARTIST_DASHBOARD
                                                            UserRole.ADMIN -> SvaraScreen.ADMIN_DASHBOARD
                                                            UserRole.SUPER_ADMIN -> SvaraScreen.SUPER_ADMIN
                                                        }
                                                    }
                                                    .padding(10.dp)
                                                    .testTag("role_option_${role.name}")
                                            ) {
                                                Text(
                                                    text = role.name,
                                                    color = if (currentUser?.role == role) RoyalGold else Color.White,
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }

                                        Divider(color = BorderGoldGray, modifier = Modifier.padding(vertical = 4.dp))

                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable {
                                                    authManager.signOut()
                                                    showRoleSwitcher = false
                                                }
                                                .padding(10.dp)
                                        ) {
                                            Text("SIGN OUT", color = ErrorRed, fontSize = 11.sp, fontWeight = FontWeight.Black)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Floating Exit Detail button shown only inside full-screen player
                    if (currentScreen == SvaraScreen.PLAYER) {
                        IconButton(
                            onClick = { currentScreen = previousScreenBeforePlayer },
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(16.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.6f))
                                .testTag("player_back_arrow")
                        ) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Exit Player", tint = RoyalGold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SvaraBottomBar(
    role: UserRole,
    currentScreen: SvaraScreen,
    onScreenSelect: (SvaraScreen) -> Unit
) {
    NavigationBar(
        containerColor = Color.Black.copy(alpha = 0.95f),
        tonalElevation = 8.dp,
        modifier = Modifier
            .border(BorderStroke(1.dp, BorderGoldGray))
            .testTag("svara_bottom_navigation")
    ) {
        // Construct adaptive bottom items depending on logged role
        when (role) {
            UserRole.USER -> {
                getListenerItems().forEach { (screen, icon, name) ->
                    NavigationBarItem(
                        selected = currentScreen == screen,
                        onClick = { onScreenSelect(screen) },
                        icon = { Icon(icon, contentDescription = name) },
                        label = { Text(name, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = ObsidianBlack,
                            selectedTextColor = RoyalGold,
                            indicatorColor = RoyalGold,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        ),
                        modifier = Modifier.testTag("nav_item_${screen.route}")
                    )
                }
            }
            UserRole.ARTIST -> {
                getArtistItems().forEach { (screen, icon, name) ->
                    NavigationBarItem(
                        selected = currentScreen == screen,
                        onClick = { onScreenSelect(screen) },
                        icon = { Icon(icon, contentDescription = name) },
                        label = { Text(name, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = ObsidianBlack,
                            selectedTextColor = RoyalGold,
                            indicatorColor = RoyalGold,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        ),
                        modifier = Modifier.testTag("nav_item_${screen.route.replace("/", "_")}")
                    )
                }
            }
            UserRole.ADMIN -> {
                getAdminItems().forEach { (screen, icon, name) ->
                    NavigationBarItem(
                        selected = currentScreen == screen,
                        onClick = { onScreenSelect(screen) },
                        icon = { Icon(icon, contentDescription = name) },
                        label = { Text(name, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = ObsidianBlack,
                            selectedTextColor = RoyalGold,
                            indicatorColor = RoyalGold,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        ),
                        modifier = Modifier.testTag("nav_item_${screen.route.replace("/", "_")}")
                    )
                }
            }
            UserRole.SUPER_ADMIN -> {
                // Single view dashboard
                NavigationBarItem(
                    selected = true,
                    onClick = { onScreenSelect(SvaraScreen.SUPER_ADMIN) },
                    icon = { Icon(Icons.Default.Dns, contentDescription = "Cluster") },
                    label = { Text("Super Admin", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = ObsidianBlack,
                        selectedTextColor = RoyalGold,
                        indicatorColor = RoyalGold
                    )
                )
            }
        }
    }
}

@Composable
fun SvaraNavigationRail(
    role: UserRole,
    currentScreen: SvaraScreen,
    onScreenSelect: (SvaraScreen) -> Unit
) {
    NavigationRail(
        containerColor = Color.Black.copy(alpha = 0.95f),
        modifier = Modifier
            .fillMaxHeight()
            .border(BorderStroke(1.dp, BorderGoldGray)),
        header = {
            Text(
                text = "SVĀRA",
                color = RoyalGold,
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 4.sp,
                fontFamily = FontFamily.Serif,
                modifier = Modifier.padding(vertical = 24.dp)
            )
        }
    ) {
        when (role) {
            UserRole.USER -> {
                getListenerItems().forEach { (screen, icon, name) ->
                    NavigationRailItem(
                        selected = currentScreen == screen,
                        onClick = { onScreenSelect(screen) },
                        icon = { Icon(icon, contentDescription = name) },
                        label = { Text(name, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                        colors = NavigationRailItemDefaults.colors(
                            selectedIconColor = ObsidianBlack,
                            selectedTextColor = RoyalGold,
                            indicatorColor = RoyalGold,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        )
                    )
                }
            }
            UserRole.ARTIST -> {
                getArtistItems().forEach { (screen, icon, name) ->
                    NavigationRailItem(
                        selected = currentScreen == screen,
                        onClick = { onScreenSelect(screen) },
                        icon = { Icon(icon, contentDescription = name) },
                        label = { Text(name, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                        colors = NavigationRailItemDefaults.colors(
                            selectedIconColor = ObsidianBlack,
                            selectedTextColor = RoyalGold,
                            indicatorColor = RoyalGold,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        )
                    )
                }
            }
            UserRole.ADMIN -> {
                getAdminItems().forEach { (screen, icon, name) ->
                    NavigationRailItem(
                        selected = currentScreen == screen,
                        onClick = { onScreenSelect(screen) },
                        icon = { Icon(icon, contentDescription = name) },
                        label = { Text(name, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                        colors = NavigationRailItemDefaults.colors(
                            selectedIconColor = ObsidianBlack,
                            selectedTextColor = RoyalGold,
                            indicatorColor = RoyalGold,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        )
                    )
                }
            }
            UserRole.SUPER_ADMIN -> {
                NavigationRailItem(
                    selected = true,
                    onClick = { onScreenSelect(SvaraScreen.SUPER_ADMIN) },
                    icon = { Icon(Icons.Default.Dns, contentDescription = "Cluster") },
                    label = { Text("Super System") },
                    colors = NavigationRailItemDefaults.colors(
                        selectedIconColor = ObsidianBlack,
                        selectedTextColor = RoyalGold,
                        indicatorColor = RoyalGold
                    )
                )
            }
        }
    }
}

@Composable
fun SvaraMiniPlayer(
    track: com.example.lib.audio.Track,
    isPlaying: Boolean,
    onToggle: () -> Unit,
    onExpand: () -> Unit
) {
    val progress by AudioPlayerManager.playbackProgress.collectAsState()

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onExpand() }
            .testTag("svara_mini_player"),
        colors = CardDefaults.cardColors(containerColor = CardSurfaceDark.copy(alpha = 0.95f)),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, BorderGoldGray)
    ) {
        Column {
            Row(
                modifier = Modifier
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AsyncImage(
                    model = track.coverArtUrl,
                    contentDescription = "Cover Mini art",
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color.DarkGray)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = track.title,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        maxLines = 1,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                    )
                    Text(
                        text = track.artist,
                        color = ChampagneGold,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                    )
                }

                // Explicit 48dp+ interactive buttons
                IconButton(
                    onClick = onToggle,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("mini_player_toggle")
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = "Toggle Performance",
                        tint = RoyalGold,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Spacer(modifier = Modifier.width(4.dp))

                IconButton(
                    onClick = onExpand,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("mini_player_expand")
                ) {
                    Icon(
                        imageVector = Icons.Default.OpenInFull,
                        contentDescription = "Expand Player Details",
                        tint = ChampagneGold,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Real-time linear progress bar at the bottom edge of mini-player card
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp),
                color = RoyalGold,
                trackColor = Color.Gray.copy(alpha = 0.2f)
            )
        }
    }
}

// Navigation lists definitions
private fun getListenerItems() = listOf(
    Triple(SvaraScreen.HOME, Icons.Default.Home, "Home"),
    Triple(SvaraScreen.SEARCH, Icons.Default.Search, "Search"),
    Triple(SvaraScreen.LIBRARY, Icons.Default.LibraryMusic, "Library")
)

private fun getArtistItems() = listOf(
    Triple(SvaraScreen.ARTIST_DASHBOARD, Icons.Default.Dashboard, "Dashboard"),
    Triple(SvaraScreen.ARTIST_UPLOAD, Icons.Default.UploadFile, "Upload"),
    Triple(SvaraScreen.ARTIST_RELEASES, Icons.Default.FolderShared, "Releases"),
    Triple(SvaraScreen.ARTIST_ANALYTICS, Icons.Default.BarChart, "Analytics"),
    Triple(SvaraScreen.ARTIST_SETTINGS, Icons.Default.Settings, "Profile")
)

private fun getAdminItems() = listOf(
    Triple(SvaraScreen.ADMIN_DASHBOARD, Icons.Default.AdminPanelSettings, "Console"),
    Triple(SvaraScreen.ADMIN_APPROVALS, Icons.Default.TaskAlt, "Approvals"),
    Triple(SvaraScreen.ADMIN_FEATURED, Icons.Default.FeaturedPlayList, "Featured"),
    Triple(SvaraScreen.ADMIN_USERS, Icons.Default.PeopleAlt, "Roles")
)
